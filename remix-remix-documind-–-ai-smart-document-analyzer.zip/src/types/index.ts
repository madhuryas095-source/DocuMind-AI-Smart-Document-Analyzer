export type Language = 'en' | 'ta' | 'hi' | 'te' | 'ml' | 'kn';

export type AppMode = 'offline' | 'online';

export type NavView =
  | 'landing'
  | 'mode-select'
  | 'dashboard'
  | 'documents'
  | 'analyze'
  | 'compare'
  | 'conflicts'
  | 'actions'
  | 'alerts'
  | 'voice'
  | 'privacy';

export interface ActionItem {
  id: string;
  task: string;
  priority: 'high' | 'medium' | 'low';
  deadline: string | null;
  assignee: string;
  completed?: boolean;
}

export interface DeadlineItem {
  id: string;
  title: string;
  date: string;
  urgency: 'critical' | 'warning' | 'normal';
  details: string;
}

export interface ImportantInfo {
  facts: string[];
  names: string[];
  dates: string[];
  amounts: string[];
  locations: string[];
  requirements: string[];
}

export interface ClarityBreakdown {
  readability: number;
  missingInfo: number;
  ambiguousStatements: number;
  complexSentences: number;
  contradictions: number;
  keyInfoVisibility: number;
}

export interface AnalysisResult {
  summary: string;
  documentType: string;
  wordCount: number;
  clarityScore: number;
  clarityBreakdown: ClarityBreakdown;
  clarityRecommendations: string[];
  importantInformation: ImportantInfo;
  actionItems: ActionItem[];
  deadlines: DeadlineItem[];
  potentialRisks: string[];
  source?: 'gemini-3.8-flash' | 'local-heuristic';
}

export interface ConflictItem {
  id: string;
  title: string;
  category: 'Deadline' | 'Financial' | 'Requirement' | 'Liability' | 'Scope';
  docAQuote: string;
  docBQuote: string;
  severity: 'high' | 'medium' | 'low';
  explanation: string;
  suggestedAction: string;
  status: 'unresolved' | 'resolved' | 'ignored' | 'important';
}

export interface ComparisonResult {
  comparisonSummary: string;
  addedInformation: string[];
  removedInformation: string[];
  modifiedInformation: string[];
  differentDates: Array<{
    topic: string;
    dateA: string;
    dateB: string;
    severity: 'critical' | 'warning' | 'info';
  }>;
  differentAmounts: Array<{
    item: string;
    amountA: string;
    amountB: string;
    difference: string;
  }>;
  changedRequirements: Array<{
    topic: string;
    reqA: string;
    reqB: string;
  }>;
  conflicts: ConflictItem[];
  source?: 'gemini-3.8-flash' | 'local-heuristic';
}

export interface DocumentRecord {
  id: string;
  title: string;
  fileName: string;
  fileSize: number;
  fileType: string;
  uploadedAt: string;
  content: string;
  analysis?: AnalysisResult;
}

export interface SmartAlert {
  id: string;
  title: string;
  message: string;
  category: 'deadline' | 'conflict' | 'task' | 'warning' | 'info';
  timestamp: string;
  read: boolean;
  actionView?: NavView;
  targetId?: string;
}
