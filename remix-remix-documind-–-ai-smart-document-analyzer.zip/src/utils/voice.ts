import { Language } from '../types';

export interface VoiceEngineState {
  isSpeaking: boolean;
  isPaused: boolean;
  isListening: boolean;
  speechRate: number;
}

type SpeechCallback = (text: string) => void;
type StateCallback = (state: VoiceEngineState) => void;

class VoiceService {
  private synth: SpeechSynthesis | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private recognition: any = null;
  private speechRate: number = 1.0;
  private isSpeaking: boolean = false;
  private isPaused: boolean = false;
  private isListening: boolean = false;
  private stateListeners: Set<StateCallback> = new Set();

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
    }
  }

  public subscribe(cb: StateCallback): () => void {
    this.stateListeners.add(cb);
    cb(this.getState());
    return () => {
      this.stateListeners.delete(cb);
    };
  }

  private notify() {
    const s = this.getState();
    this.stateListeners.forEach((cb) => cb(s));
  }

  public getState(): VoiceEngineState {
    return {
      isSpeaking: this.isSpeaking,
      isPaused: this.isPaused,
      isListening: this.isListening,
      speechRate: this.speechRate,
    };
  }

  public setRate(rate: number) {
    this.speechRate = Math.max(0.5, Math.min(2.0, rate));
    if (this.currentUtterance && this.isSpeaking) {
      // Note: In browser speech synthesis, changing rate requires restarting utterance
      this.notify();
    }
  }

  public getRate(): number {
    return this.speechRate;
  }

  public speak(
    text: string,
    lang: Language = 'en',
    onEnd?: () => void,
    onError?: (err: any) => void
  ) {
    if (!this.synth) {
      console.warn('Speech synthesis not available in this environment');
      return;
    }

    this.stop(); // Stop any active speech

    // Clean text of markdown backticks or bullet symbols
    const cleanText = text
      .replace(/[*#_~`>]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = this.speechRate;
    utterance.pitch = 1.0;

    // Pick best available voice for language
    const langCodeMap: Record<Language, string> = {
      en: 'en-US',
      hi: 'hi-IN',
      ta: 'ta-IN',
      te: 'te-IN',
      ml: 'ml-IN',
      kn: 'kn-IN',
    };
    const targetLocale = langCodeMap[lang] || 'en-US';
    utterance.lang = targetLocale;

    const voices = this.synth.getVoices();
    const matchedVoice =
      voices.find((v) => v.lang.startsWith(targetLocale) || v.lang.startsWith(targetLocale.slice(0, 2))) ||
      voices.find((v) => v.lang.startsWith('en'));

    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    utterance.onstart = () => {
      this.isSpeaking = true;
      this.isPaused = false;
      this.notify();
    };

    utterance.onend = () => {
      this.isSpeaking = false;
      this.isPaused = false;
      this.currentUtterance = null;
      this.notify();
      if (onEnd) onEnd();
    };

    utterance.onerror = (e) => {
      this.isSpeaking = false;
      this.isPaused = false;
      this.currentUtterance = null;
      this.notify();
      if (onError) onError(e);
    };

    this.currentUtterance = utterance;
    this.synth.speak(utterance);
  }

  public pause() {
    if (this.synth && this.isSpeaking && !this.isPaused) {
      this.synth.pause();
      this.isPaused = true;
      this.notify();
    }
  }

  public resume() {
    if (this.synth && this.isPaused) {
      this.synth.resume();
      this.isPaused = false;
      this.notify();
    }
  }

  public stop() {
    if (this.synth) {
      this.synth.cancel();
      this.isSpeaking = false;
      this.isPaused = false;
      this.currentUtterance = null;
      this.notify();
    }
  }

  // Speech Recognition (Web Speech API)
  public startListening(
    lang: Language = 'en',
    onResult: SpeechCallback,
    onError?: (err: any) => void
  ): boolean {
    if (typeof window === 'undefined') return false;

    const SpeechRecClass =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecClass) {
      console.warn('SpeechRecognition API not supported in this browser');
      return false;
    }

    try {
      if (this.recognition) {
        this.recognition.abort();
      }

      this.recognition = new SpeechRecClass();
      const langCodeMap: Record<Language, string> = {
        en: 'en-US',
        hi: 'hi-IN',
        ta: 'ta-IN',
        te: 'te-IN',
        ml: 'ml-IN',
        kn: 'kn-IN',
      };
      this.recognition.lang = langCodeMap[lang] || 'en-US';
      this.recognition.continuous = false;
      this.recognition.interimResults = false;

      this.recognition.onstart = () => {
        this.isListening = true;
        this.notify();
      };

      this.recognition.onresult = (event: any) => {
        const transcript = event.results[0]?.[0]?.transcript || '';
        this.isListening = false;
        this.notify();
        onResult(transcript);
      };

      this.recognition.onerror = (err: any) => {
        this.isListening = false;
        this.notify();
        if (onError) onError(err);
      };

      this.recognition.onend = () => {
        this.isListening = false;
        this.notify();
      };

      this.recognition.start();
      return true;
    } catch (e) {
      this.isListening = false;
      this.notify();
      if (onError) onError(e);
      return false;
    }
  }

  public stopListening() {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {}
      this.isListening = false;
      this.notify();
    }
  }
}

export const voiceEngine = new VoiceService();
