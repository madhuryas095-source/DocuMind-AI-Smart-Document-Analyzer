import { DocumentRecord, ComparisonResult } from '../types';

export const DEMO_DOC_A_CONTRACT: DocumentRecord = {
  id: 'demo-doc-contract-v1',
  title: 'Master Services Agreement (MSA) v1.0',
  fileName: 'MSA_Enterprise_Agreement_v1.0.pdf',
  fileSize: 42800,
  fileType: 'application/pdf',
  uploadedAt: '2026-10-01T10:00:00Z',
  content: `MASTER SERVICES AGREEMENT (v1.0)
BETWEEN: Apex Cloud Innovations LLC ("Client")
AND: Horizon Engineering Solutions Ltd ("Vendor")
EFFECTIVE DATE: 15 August 2026

1. SCOPE OF SERVICES
Vendor shall architect, build, and deploy the automated customer intelligence pipeline across 3 phased sprints:
- Sprint 1: Data ingestion pipeline and data warehouse setup.
- Sprint 2: Core analytical models and dashboard UI.
- Sprint 3: End-to-end integration and load testing.

2. TIMELINE & DEADLINES
2.1 Primary Milestone: The final application delivery and acceptance testing deadline shall be strictly 15 October 2026.
2.2 Review Windows: Client shall provide written approval or change feedback within 5 business days of each milestone delivery.

3. COMPENSATION & FEES
3.1 Total contract remuneration is fixed at $45,000 USD, payable on Net-30 terms upon receipt of invoice.
3.2 An early delivery incentive bonus of $2,500 USD shall be disbursed if production deployment completes before 01 October 2026.

4. REQUIRED ACTION ITEMS
- Vendor must submit weekly sprint progress reports every Friday at 5:00 PM EST.
- Vendor lead architect must attend weekly coordination meetings on Monday mornings.
- Vendor must upload compliance certificates and proof of insurance prior to sprint commencement.
- Client must provide sandbox API credentials and test data payloads by 20 August 2026.

5. PENALTIES & LIABILITY
5.1 Late delivery penalty: In the event of unexcused milestone delay, Vendor shall pay liquidated damages of 1% per full working week of delay, capped at 5% of total contract value.
5.2 Warranty: Vendor provides a 90-day complimentary bug fixing and maintenance support period following final production launch.

6. GOVERNING LAW
This Agreement shall be governed in accordance with the laws of Delaware.`,
  analysis: {
    summary:
      'Master Services Agreement v1.0 sets a fixed budget of $45,000 USD and mandates final application delivery by 15 October 2026 across 3 sprint phases. Features standard Net-30 payment terms, 90-day complimentary post-launch support, and a capped 5% late delivery penalty.',
    documentType: 'Commercial Contract & Legal MSA',
    wordCount: 295,
    clarityScore: 88,
    clarityBreakdown: {
      readability: 90,
      missingInfo: 84,
      ambiguousStatements: 86,
      complexSentences: 88,
      contradictions: 95,
      keyInfoVisibility: 92,
    },
    clarityRecommendations: [
      'Clarify specific timezone and method for submitting weekly Friday progress reports.',
      'Specify sandbox credential encryption standards in Section 4.',
    ],
    importantInformation: {
      facts: [
        'Fixed remuneration of $45,000 USD with Net-30 payment terms.',
        'Early delivery incentive bonus of $2,500 USD for completion before October 1, 2026.',
        'Post-launch complimentary warranty support is guaranteed for 90 days.',
      ],
      names: ['Apex Cloud Innovations LLC (Client)', 'Horizon Engineering Solutions Ltd (Vendor)'],
      dates: ['15 August 2026 (Effective)', '15 October 2026 (Final Delivery)', '20 August 2026 (Credentials Due)'],
      amounts: ['$45,000 USD (Base Total)', '$2,500 USD (Early Bonus)', '1% per week delay penalty (capped at 5%)'],
      locations: ['Delaware (Governing Jurisdiction)', 'Cloud Infrastructure Sandbox'],
      requirements: [
        'Weekly Friday sprint reports submitted by 5:00 PM EST.',
        'Compliance certificates and insurance proof uploaded prior to work start.',
      ],
    },
    actionItems: [
      {
        id: 'act-1',
        task: 'Submit proof of commercial liability insurance and compliance certificate',
        priority: 'high',
        deadline: '20 August 2026',
        assignee: 'Vendor Operations',
        completed: true,
      },
      {
        id: 'act-2',
        task: 'Provide sandbox API credentials and sanitized test data payloads',
        priority: 'high',
        deadline: '20 August 2026',
        assignee: 'Apex Cloud IT Team',
        completed: true,
      },
      {
        id: 'act-3',
        task: 'Attend weekly architectural coordination standup on Mondays',
        priority: 'medium',
        deadline: 'Weekly',
        assignee: 'Vendor Lead Architect',
        completed: false,
      },
      {
        id: 'act-4',
        task: 'Complete final application deployment and acceptance sign-off',
        priority: 'high',
        deadline: '15 October 2026',
        assignee: 'Joint Project Sponsor',
        completed: false,
      },
    ],
    deadlines: [
      {
        id: 'dl-1',
        title: 'Final Application Delivery & Acceptance Cutoff',
        date: '15 October 2026',
        urgency: 'critical',
        details: 'Mandatory completion deadline under Section 2.1 before delay penalties accrue.',
      },
      {
        id: 'dl-2',
        title: 'Early Delivery Incentive Bonus Cutoff',
        date: '01 October 2026',
        urgency: 'warning',
        details: 'Qualifies Vendor for an additional $2,500 performance bonus.',
      },
      {
        id: 'dl-3',
        title: 'Sandbox API Credentials Provisioning',
        date: '20 August 2026',
        urgency: 'normal',
        details: 'Client required to provide test environments to unblock Sprint 1.',
      },
    ],
    potentialRisks: [
      'Liquidated damages penalty triggers if final milestone exceeds 15 October 2026.',
      'Net-30 payment term may impact vendor cash-flow during multi-month delivery.',
    ],
    source: 'gemini-3.8-flash',
  },
};

export const DEMO_DOC_B_CONTRACT: DocumentRecord = {
  id: 'demo-doc-contract-v2',
  title: 'Master Services Agreement (MSA) v2.0 - Revised Addendum',
  fileName: 'MSA_Enterprise_Agreement_v2.0_Revised.pdf',
  fileSize: 48900,
  fileType: 'application/pdf',
  uploadedAt: '2026-10-04T14:30:00Z',
  content: `MASTER SERVICES AGREEMENT (v2.0 REVISED)
BETWEEN: Apex Cloud Innovations LLC ("Client")
AND: Horizon Engineering Solutions Ltd ("Vendor")
REVISION DATE: 02 October 2026

1. SCOPE OF SERVICES (AMENDED)
Vendor shall architect, build, and deploy the automated customer intelligence pipeline across 4 phased sprints:
- Sprint 1: Data ingestion pipeline and data warehouse setup.
- Sprint 2: Core analytical models and AI prediction pipeline.
- Sprint 3: High-availability dashboard UI and mobile views.
- Sprint 4: Independent SOC2 Type II security audit, pen testing, and acceptance.

2. TIMELINE & DEADLINES (MODIFIED)
2.1 Primary Milestone: The final application delivery and acceptance testing deadline shall be 20 October 2026.
2.2 Review Windows: Client shall provide review feedback within 3 business days of milestone submission.

3. COMPENSATION & FEES (ADJUSTED)
3.1 Total contract remuneration is revised upward to $58,000 USD, payable in 4 tranche payments on 15-day terms upon sprint milestone sign-off.
3.2 An early delivery incentive bonus of $5,000 USD shall be awarded if all 4 sprints complete before 10 October 2026.

4. REQUIRED ACTION ITEMS
- Vendor must submit daily automated build reports and CI/CD status logs.
- Vendor lead architect must attend mandatory daily standup at 9:00 AM EST.
- Vendor must provide an independent SOC2 Type II audit report and 3rd party penetration test before final payment release.
- Client must release milestone funds within 15 days of verified acceptance.

5. PENALTIES & LIABILITY (STRENGTHENED)
5.1 Late delivery penalty: In the event of unexcused milestone delay, Vendor shall be liable for 2% per calendar day of delay, without monetary cap.
5.2 Intellectual Property: All underlying machine learning training pipelines and proprietary neural weights are assigned 100% exclusively to Client.
5.3 Warranty: Complimentary warranty is removed; ongoing maintenance requires an auxiliary SLA agreement at $2,500/month.

6. GOVERNING LAW & JURISDICTION
This Agreement shall be governed in accordance with the laws of New York, and subject to binding arbitration in Manhattan, NY.`,
  analysis: {
    summary:
      'Revised Master Services Agreement v2.0 introduces major structural changes: budget increased to $58,000 USD, deadline shifted to 20 October 2026 with a 4th SOC2 security sprint. Notably removes the free 90-day warranty and escalates late delivery penalties to an uncapped 2% per calendar day.',
    documentType: 'Commercial Contract & Legal MSA (Amendment)',
    wordCount: 342,
    clarityScore: 84,
    clarityBreakdown: {
      readability: 84,
      missingInfo: 86,
      ambiguousStatements: 82,
      complexSentences: 80,
      contradictions: 88,
      keyInfoVisibility: 90,
    },
    clarityRecommendations: [
      'Establish a mutual liability ceiling in Section 5.1 to prevent catastrophic exposure from uncapped daily penalties.',
      'Define standard arbitration rules (e.g. AAA or JAMS) under Section 6 dispute resolution.',
    ],
    importantInformation: {
      facts: [
        'Budget revised to $58,000 USD paid across 4 tranches on 15-day terms.',
        'Scope expanded to include 4th sprint for SOC2 Type II audit & pen testing.',
        'All AI neural weights and training pipeline assigned exclusively to Client.',
        'Complimentary 90-day warranty deleted; replaced by $2,500/mo optional SLA.',
      ],
      names: ['Apex Cloud Innovations LLC (Client)', 'Horizon Engineering Solutions Ltd (Vendor)'],
      dates: ['02 October 2026 (Revision)', '20 October 2026 (Final Delivery)', '10 October 2026 (Bonus Cutoff)'],
      amounts: ['$58,000 USD (Revised Total)', '$5,000 USD (Early Bonus)', '2% per day uncapped penalty', '$2,500/mo (Optional SLA)'],
      locations: ['New York / Manhattan Arbitration', 'SOC2 Cloud Infrastructure'],
      requirements: [
        'Mandatory daily CI/CD logs and 9:00 AM EST daily standup attendance.',
        'Independent 3rd-party penetration test and SOC2 Type II audit report.',
      ],
    },
    actionItems: [
      {
        id: 'act-1',
        task: 'Commission independent third-party penetration test and SOC2 Type II audit',
        priority: 'high',
        deadline: '15 October 2026',
        assignee: 'Vendor Security Officer',
        completed: false,
      },
      {
        id: 'act-2',
        task: 'Setup automated daily CI/CD telemetry dashboard and build log exports',
        priority: 'medium',
        deadline: '05 October 2026',
        assignee: 'DevOps Lead',
        completed: true,
      },
      {
        id: 'act-3',
        task: 'Attend mandatory daily standup meeting at 9:00 AM EST',
        priority: 'medium',
        deadline: 'Daily',
        assignee: 'Vendor Project Team',
        completed: false,
      },
      {
        id: 'act-4',
        task: 'Finalize 4-phase delivery and acceptance sign-off by revised deadline',
        priority: 'high',
        deadline: '20 October 2026',
        assignee: 'Executive Sponsor',
        completed: false,
      },
    ],
    deadlines: [
      {
        id: 'dl-1',
        title: 'Revised Final Delivery & Acceptance Cutoff',
        date: '20 October 2026',
        urgency: 'critical',
        details: 'Shifts deadline 5 days later than v1.0, but invokes severe uncapped 2%/day late penalties thereafter.',
      },
      {
        id: 'dl-2',
        title: 'Accelerated Early Bonus Cutoff',
        date: '10 October 2026',
        urgency: 'warning',
        details: 'Vendor eligible for $5,000 incentive if 4 sprints conclude by this date.',
      },
    ],
    potentialRisks: [
      'Uncapped 2% per calendar day penalty represents high commercial liability risk for vendor.',
      'Loss of complimentary post-launch support forces client to incur $2,500/mo additional overhead.',
    ],
    source: 'gemini-3.8-flash',
  },
};

export const DEMO_DOC_ADMISSIONS: DocumentRecord = {
  id: 'demo-doc-admissions',
  title: 'Global University Graduate Fellowship & Admission Guide 2026',
  fileName: 'Graduate_Admissions_Fellowship_Guide_2026.pdf',
  fileSize: 52100,
  fileType: 'application/pdf',
  uploadedAt: '2026-10-02T08:15:00Z',
  content: `GRADUATE ADMISSIONS & MERIT FELLOWSHIP DIRECTIVE (ACADEMIC YEAR 2026-2027)
Office of Graduate Studies & Research Excellence

1. ADMISSION ELIGIBILITY & PREREQUISITES
Applicants must hold an accredited Bachelor's degree with a minimum cumulative GPA of 3.5/4.0 or equivalent. International applicants whose primary medium of undergraduate instruction was not English must submit TOEFL (minimum score: 102) or IELTS (minimum score: 7.5) test results dated within the past 24 months.

2. MANDATORY APPLICATION DEADLINES
- Priority Fellowship Consideration: 15 October 2026 at 11:59 PM EST. (Late applications will not be evaluated for the $32,000 annual stipend).
- General Graduate Application Final Cutoff: 01 November 2026 at 11:59 PM EST.
- Financial Aid Verification & Tax Document Upload: 15 November 2026.
- Virtual Oral Interview Round: 01 December 2026 through 08 December 2026.
- Final Admission & Fellowship Decisions Released: 15 December 2026.
- Acceptance of Offer and Intent to Enroll Fee ($500 USD): 15 January 2027.

3. REQUIRED ACTION ITEMS & CHECKLIST
☑ Submit online portal application form with $90 USD non-refundable processing fee.
☑ Upload verified digital transcripts from all prior post-secondary institutions.
☑ Submit three (3) confidential academic recommendation letters via portal links.
☑ Upload a 1,000-word Statement of Purpose addressing planned research focus.
☑ Upload official GRE score report (optional for STEM disciplines, recommended for fellowship consideration).
☑ Attend mandatory 20-minute virtual oral panel interview if shortlisted.

4. MERIT FELLOWSHIPS & FINANCIAL ASSISTANCE
Top 10% of admitted doctoral candidates are automatically considered for the Chancellor's Excellence Fellowship, comprising:
- 100% full tuition waiver ($48,000 USD per academic year).
- Annual living stipend of $32,000 USD distributed over 10 equal monthly disbursements.
- Comprehensive student health insurance subsidy ($3,400 USD value).
- $2,000 USD annual academic conference travel allowance.

5. IMPORTANT REQUIREMENTS & RESTRICTIONS
Fellowship recipients are prohibited from holding outside commercial employment exceeding 10 hours per week during academic terms. Maintaining a minimum semester GPA of 3.65 is mandatory for renewal.`,
  analysis: {
    summary:
      'Official Graduate Admissions & Fellowship Directive for Academic Year 2026-2027. Outlines rigorous criteria including priority fellowship deadline of 15 October 2026, $32,000 annual living stipend, tuition remission, and a strict 6-step submission checklist.',
    documentType: 'Academic Directive & Fellowship Guidelines',
    wordCount: 388,
    clarityScore: 94,
    clarityBreakdown: {
      readability: 92,
      missingInfo: 96,
      ambiguousStatements: 94,
      complexSentences: 90,
      contradictions: 98,
      keyInfoVisibility: 95,
    },
    clarityRecommendations: [
      'Provide a link or format guideline for the 1,000-word Statement of Purpose.',
      'Specify exact timezone handling for international applicants outside EST.',
    ],
    importantInformation: {
      facts: [
        'Priority fellowship deadline is strictly 15 October 2026; late submissions forfeit $32,000 stipend consideration.',
        'Chancellor’s Fellowship provides 100% tuition waiver ($48,000) and $32,000 annual living stipend.',
        'Outside employment strictly restricted to maximum 10 hours per week for fellows.',
      ],
      names: ['Office of Graduate Studies', 'Chancellor’s Fellowship Committee'],
      dates: [
        '15 October 2026 (Priority Fellowship)',
        '01 November 2026 (General Cutoff)',
        '15 November 2026 (Financial Aid Docs)',
        '01-08 December 2026 (Oral Interviews)',
        '15 December 2026 (Decisions)',
      ],
      amounts: [
        '$90 USD (Application Fee)',
        '$500 USD (Enrollment Deposit)',
        '$48,000 USD (Tuition Remission)',
        '$32,000 USD (Annual Living Stipend)',
        '$2,000 USD (Conference Grant)',
      ],
      locations: ['Virtual Admissions Portal', 'Graduate Admissions Office'],
      requirements: [
        'Minimum undergraduate GPA of 3.5/4.0.',
        'Three confidential academic recommendation letters.',
        '1,000-word Statement of Purpose detailing research focus.',
      ],
    },
    actionItems: [
      {
        id: 'act-1',
        task: 'Submit online portal application and pay $90 processing fee',
        priority: 'high',
        deadline: '15 October 2026',
        assignee: 'Applicant',
        completed: false,
      },
      {
        id: 'act-2',
        task: 'Upload verified digital transcripts from all universities attended',
        priority: 'high',
        deadline: '15 October 2026',
        assignee: 'Applicant',
        completed: false,
      },
      {
        id: 'act-3',
        task: 'Follow up with 3 academic professors to submit recommendation letters',
        priority: 'high',
        deadline: '15 October 2026',
        assignee: 'Applicant Recommenders',
        completed: false,
      },
      {
        id: 'act-4',
        task: 'Upload final 1,000-word Statement of Purpose research essay',
        priority: 'medium',
        deadline: '15 October 2026',
        assignee: 'Applicant',
        completed: true,
      },
      {
        id: 'act-5',
        task: 'Attend mandatory 20-minute virtual oral panel interview if shortlisted',
        priority: 'high',
        deadline: '01 December 2026',
        assignee: 'Shortlisted Candidate',
        completed: false,
      },
    ],
    deadlines: [
      {
        id: 'dl-1',
        title: 'Priority Fellowship Consideration Deadline',
        date: '15 October 2026',
        urgency: 'critical',
        details: 'Essential cutoff for $32,000 annual living stipend and full tuition waiver.',
      },
      {
        id: 'dl-2',
        title: 'General Graduate Application Final Cutoff',
        date: '01 November 2026',
        urgency: 'warning',
        details: 'Last day for standard admission without merit fellowship eligibility.',
      },
      {
        id: 'dl-3',
        title: 'Financial Aid & Tax Document Upload',
        date: '15 November 2026',
        urgency: 'normal',
        details: 'Institutional verification for need-based student grants and loans.',
      },
      {
        id: 'dl-4',
        title: 'Virtual Oral Panel Interviews',
        date: '01 December 2026',
        urgency: 'warning',
        details: 'Mandatory interview window for shortlisted applicants.',
      },
    ],
    potentialRisks: [
      'Missing the 15 October 2026 priority deadline disqualifies applicant from $32,000 fellowship.',
      'Exceeding the 10 hour/week outside employment restriction results in automatic fellowship revocation.',
    ],
    source: 'gemini-3.8-flash',
  },
};

export const DEMO_DOC_POLICY: DocumentRecord = {
  id: 'demo-doc-policy',
  title: 'Hybrid Workplace Security & Flexibility Policy 2026',
  fileName: 'Hybrid_Workplace_Security_Policy_2026.docx',
  fileSize: 37400,
  fileType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  uploadedAt: '2026-10-03T11:45:00Z',
  content: `CORPORATE WORKPLACE OPERATIONS & INFORMATION SECURITY DIRECTIVE
POLICY: Remote & Hybrid Work Protocols (Revision 2026.3)
AUDIENCE: All Global Full-Time Employees & Contractors

1. CORE WORKING HOURS & EXPECTATIONS
Employees operating under hybrid status are expected to remain reachable during reasonable business hours and maintain timely communication via company messaging channels. In-person team synchronization will occur from time to time as determined by individual department leads.

2. HARDWARE & DEVICE COMPLIANCE
2.1 All employees must utilize company-issued laptops or certified virtual desktop infrastructure (VDI).
2.2 Frequent system updates and antivirus patches must be applied promptly whenever prompted by the IT Operations daemon.
2.3 Connecting to public unsecured Wi-Fi networks (such as coffee shops or airports) without active VPN tunneling is strictly prohibited.

3. DATA RETENTION & SECURITY ACTIONS
☑ Enable mandatory FIDO2 hardware security keys for single-sign-on (SSO) by 15 October 2026.
☑ Complete the annual 45-minute Security Awareness Phishing Training module by 25 October 2026.
☑ Perform periodic data clean-up of temporary downloads folders containing customer Personally Identifiable Information (PII).
☑ Immediately notify the InfoSec hotline within 2 hours of any suspected security incident, lost hardware, or unauthorized access attempt.

4. EXPENSE REIMBURSEMENT
The company provides a one-time ergonomic home office stipend of up to $750 USD upon submission of valid store receipts within 60 days of onboarding. Monthly broadband internet subsidies of up to $60 USD are approved subject to manager sign-off.`,
  analysis: {
    summary:
      'Corporate Remote & Hybrid Workplace Security Policy detailing hardware compliance, FIDO2 multi-factor rollout, and home office expense stipends. Identifies notable ambiguities around vague terms like "reasonable hours" and "frequent updates".',
    documentType: 'Corporate Operational & Security Policy',
    wordCount: 268,
    clarityScore: 71,
    clarityBreakdown: {
      readability: 74,
      missingInfo: 68,
      ambiguousStatements: 62,
      complexSentences: 76,
      contradictions: 88,
      keyInfoVisibility: 78,
    },
    clarityRecommendations: [
      'Replace vague phrase "reasonable business hours" with defined core hours (e.g. 10:00 AM – 3:00 PM EST).',
      'Define exact frequency for "frequent system updates" (e.g., within 72 hours of patch release).',
      'Clarify criteria for "from time to time" in-person attendance with specific day count per month.',
    ],
    importantInformation: {
      facts: [
        'Mandatory FIDO2 security keys must be configured by 15 October 2026.',
        'One-time ergonomic stipend of $750 USD and monthly internet subsidy of $60 USD.',
        'Public Wi-Fi strictly prohibited without active VPN tunneling.',
      ],
      names: ['IT Operations Daemon', 'InfoSec Incident Response Team'],
      dates: ['15 October 2026 (FIDO2 Deadline)', '25 October 2026 (Phishing Training Deadline)'],
      amounts: ['$750 USD (Ergonomic Stipend)', '$60 USD (Monthly Internet Subsidy)'],
      locations: ['Remote Home Office', 'Company VPN Gateway'],
      requirements: [
        'Report suspected security incidents within 2 hours of discovery.',
        'Complete annual 45-minute phishing training before October 25, 2026.',
      ],
    },
    actionItems: [
      {
        id: 'act-1',
        task: 'Enable mandatory FIDO2 hardware security keys for SSO authentication',
        priority: 'high',
        deadline: '15 October 2026',
        assignee: 'All Employees',
        completed: false,
      },
      {
        id: 'act-2',
        task: 'Complete annual 45-minute Security Awareness Phishing Training module',
        priority: 'medium',
        deadline: '25 October 2026',
        assignee: 'All Employees',
        completed: false,
      },
      {
        id: 'act-3',
        task: 'Submit home ergonomic office receipts for $750 stipend reimbursement',
        priority: 'low',
        deadline: '60 days post-onboarding',
        assignee: 'Remote Workers',
        completed: true,
      },
    ],
    deadlines: [
      {
        id: 'dl-1',
        title: 'FIDO2 Security Key Mandatory Enforcement Cutoff',
        date: '15 October 2026',
        urgency: 'critical',
        details: 'Accounts without FIDO2 enabled will experience locked SSO access.',
      },
      {
        id: 'dl-2',
        title: 'Annual InfoSec Phishing Training Deadline',
        date: '25 October 2026',
        urgency: 'warning',
        details: 'Mandatory compliance certification for global staff.',
      },
    ],
    potentialRisks: [
      'Ambiguous core working hours lead to mismatched team availability and management friction.',
      '2-hour incident reporting window requires 24/7 hotline staffing.',
    ],
    source: 'gemini-3.8-flash',
  },
};

export const DEMO_COMPARISON_CONTRACTS: ComparisonResult = {
  comparisonSummary:
    'Comprehensive comparison between Master Services Agreement v1.0 and Revised Addendum v2.0 reveals substantive deviations: the delivery deadline has been postponed by 5 days (from 15 October to 20 October 2026), base compensation expanded from $45,000 to $58,000 USD (+28.8%), the complimentary 90-day warranty deleted, and uncapped daily late penalties introduced.',
  addedInformation: [
    'Added 4th sprint specifically dedicated to third-party SOC2 Type II audit and independent penetration testing.',
    'Added mandatory assignment of all AI model weights and training datasets 100% exclusively to Client.',
    'Added required daily 9:00 AM EST standup and automated daily CI/CD logs.',
    'Added mandatory Manhattan, NY binding arbitration jurisdiction clause.',
  ],
  removedInformation: [
    'Removed 90-day complimentary bug fixing and post-launch maintenance warranty.',
    'Removed Delaware governing jurisdiction in favor of New York venue.',
    'Removed original 5% liability cap on late delivery delay damages.',
  ],
  modifiedInformation: [
    'Delivery milestone extended by 5 calendar days: shifted from 15 October 2026 to 20 October 2026.',
    'Base fee increased from $45,000 USD to $58,000 USD (+28.8% budget adjustment).',
    'Payment terms shortened from Net-30 to 15-day milestone tranches.',
    'Early delivery bonus increased from $2,500 (Oct 1 cutoff) to $5,000 (Oct 10 cutoff).',
    'Client review window compressed from 5 business days to 3 business days.',
  ],
  differentDates: [
    {
      topic: 'Final Delivery & Acceptance Cutoff',
      dateA: '15 October 2026',
      dateB: '20 October 2026',
      severity: 'critical',
    },
    {
      topic: 'Early Completion Bonus Cutoff',
      dateA: '01 October 2026 ($2,500 bonus)',
      dateB: '10 October 2026 ($5,000 bonus)',
      severity: 'warning',
    },
    {
      topic: 'Client Review Response Window',
      dateA: '5 Business Days',
      dateB: '3 Business Days',
      severity: 'info',
    },
  ],
  differentAmounts: [
    {
      item: 'Total Contract Consideration',
      amountA: '$45,000 USD',
      amountB: '$58,000 USD',
      difference: '+$13,000 USD (+28.8% increase for added SOC2 sprint)',
    },
    {
      item: 'Early Delivery Incentive Bonus',
      amountA: '$2,500 USD',
      amountB: '$5,000 USD',
      difference: '+$2,500 USD (Doubled incentive pool)',
    },
    {
      item: 'Late Delay Penalty Formula',
      amountA: '1% per week (Capped at 5% max)',
      amountB: '2% per calendar day (Uncapped)',
      difference: 'Exponentially higher risk profile without monetary ceiling',
    },
    {
      item: 'Post-Launch Maintenance Warranty',
      amountA: 'Complimentary for 90 days ($0)',
      amountB: '$2,500 / month auxiliary SLA',
      difference: 'Transfers ongoing maintenance costs to Client',
    },
  ],
  changedRequirements: [
    {
      topic: 'Sprint Rollout & Scope Structure',
      reqA: '3 Phased sprints covering pipeline, UI models, and integration.',
      reqB: '4 Phased sprints adding external SOC2 Type II audit and pen testing.',
    },
    {
      topic: 'Reporting & Standup Cadence',
      reqA: 'Weekly Friday sprint progress report & Monday weekly architectural meeting.',
      reqB: 'Daily automated CI/CD build logs & mandatory 9:00 AM daily standup.',
    },
    {
      topic: 'Intellectual Property Ownership',
      reqA: 'Standard work-for-hire rights with vendor background technology retained.',
      reqB: 'Complete exclusive ownership of all neural models, code, and weights to Client.',
    },
  ],
  conflicts: [
    {
      id: 'conf-1',
      title: 'Contradictory Project Final Delivery Deadline',
      category: 'Deadline',
      docAQuote: '“The final application delivery and acceptance testing deadline shall be strictly 15 October 2026.”',
      docBQuote: '“The final application delivery and acceptance testing deadline shall be 20 October 2026.”',
      severity: 'high',
      explanation:
        'Direct date contradiction between revisions. Operating under v1.0 schedules would cause vendor to compress timelines by 5 days, while v2.0 delays final handover.',
      suggestedAction: 'Execute a formal timeline harmonization addendum ratifying 20 October 2026.',
      status: 'unresolved',
    },
    {
      id: 'conf-2',
      title: 'Financial Remuneration Discrepancy ($45,000 vs $58,000)',
      category: 'Financial',
      docAQuote: '“Total contract remuneration is fixed at $45,000 USD, payable on Net-30 terms.”',
      docBQuote: '“Total contract remuneration is revised upward to $58,000 USD, payable in 4 tranche payments on 15-day terms.”',
      severity: 'high',
      explanation:
        'A $13,000 price gap and conflicting disbursement terms (Net-30 vs 15-day tranche releases). Accounts payable will stall without sign-off.',
      suggestedAction: 'Finance department must verify whether the extra $13,000 for SOC2 audit is authorized.',
      status: 'unresolved',
    },
    {
      id: 'conf-3',
      title: 'Liquidated Damages Liability Conflict (Capped vs Uncapped)',
      category: 'Liability',
      docAQuote: '“Liquidated damages of 1% per full working week of delay, capped at 5% of total contract value.”',
      docBQuote: '“Vendor shall be liable for 2% per calendar day of delay, without monetary cap.”',
      severity: 'high',
      explanation:
        'Document B converts a modest weekly penalty with a safety cap into an aggressive uncapped daily penalty, multiplying delay exposure by over 14x.',
      suggestedAction: 'Legal counsel must negotiate a reasonable mutual cap (e.g. 10% maximum).',
      status: 'unresolved',
    },
    {
      id: 'conf-4',
      title: 'Complimentary Post-Launch Warranty Revocation',
      category: 'Requirement',
      docAQuote: '“Vendor provides a 90-day complimentary bug fixing and maintenance support period.”',
      docBQuote: '“Complimentary warranty is removed; ongoing maintenance requires an auxiliary SLA agreement at $2,500/month.”',
      severity: 'medium',
      explanation:
        'Document A promises free support for 3 months, whereas Document B requires immediate subscription fees.',
      suggestedAction: 'Clarify whether bug fixes for initial release are included during first 30 days.',
      status: 'unresolved',
    },
  ],
  source: 'gemini-3.8-flash',
};
