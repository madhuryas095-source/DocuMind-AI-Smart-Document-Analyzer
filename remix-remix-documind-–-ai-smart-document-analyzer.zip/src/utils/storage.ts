import {
  AppMode,
  DocumentRecord,
  Language,
  SmartAlert,
  ComparisonResult,
} from '../types';
import {
  DEMO_DOC_A_CONTRACT,
  DEMO_DOC_B_CONTRACT,
  DEMO_DOC_ADMISSIONS,
  DEMO_DOC_POLICY,
  DEMO_COMPARISON_CONTRACTS,
} from './demoData';

const STORAGE_KEYS = {
  MODE: 'documind_mode',
  PRIVACY: 'documind_privacy',
  LANGUAGE: 'documind_language',
  SOUND_MUTED: 'documind_sound_muted',
  DOCUMENTS: 'documind_documents',
  ACTIVE_DOC_ID: 'documind_active_doc_id',
  COMPARE_DOC_A: 'documind_compare_doc_a',
  COMPARE_DOC_B: 'documind_compare_doc_b',
  COMPARISON_RESULT: 'documind_comparison_result',
  CONFLICT_STATUSES: 'documind_conflict_statuses',
  ACTION_COMPLETED: 'documind_action_completed',
  ALERTS: 'documind_alerts',
};

export class StorageService {
  // Mode
  static getMode(): AppMode {
    if (typeof window === 'undefined') return 'offline';
    return (localStorage.getItem(STORAGE_KEYS.MODE) as AppMode) || 'offline';
  }

  static setMode(mode: AppMode) {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.MODE, mode);
    }
  }

  // Privacy Mode
  static getPrivacyMode(): boolean {
    if (typeof window === 'undefined') return true;
    const val = localStorage.getItem(STORAGE_KEYS.PRIVACY);
    return val !== null ? val === 'true' : true; // Default to true (privacy-first)
  }

  static setPrivacyMode(enabled: boolean) {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.PRIVACY, String(enabled));
    }
  }

  // Language
  static getLanguage(): Language {
    if (typeof window === 'undefined') return 'en';
    return (localStorage.getItem(STORAGE_KEYS.LANGUAGE) as Language) || 'en';
  }

  static setLanguage(lang: Language) {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.LANGUAGE, lang);
    }
  }

  // Sound
  static isSoundMuted(): boolean {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem(STORAGE_KEYS.SOUND_MUTED) === 'true';
  }

  static setSoundMuted(muted: boolean) {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.SOUND_MUTED, String(muted));
    }
  }

  // Documents
  static getDocuments(): DocumentRecord[] {
    if (typeof window === 'undefined') return [DEMO_DOC_A_CONTRACT, DEMO_DOC_B_CONTRACT];
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.DOCUMENTS);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {}
    // Seed with initial demo documents
    const initial = [DEMO_DOC_A_CONTRACT, DEMO_DOC_B_CONTRACT, DEMO_DOC_ADMISSIONS, DEMO_DOC_POLICY];
    this.saveDocuments(initial);
    return initial;
  }

  static saveDocuments(docs: DocumentRecord[]) {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEYS.DOCUMENTS, JSON.stringify(docs));
      } catch (e) {
        console.warn('LocalStorage limit exceeded, trimming older documents', e);
      }
    }
  }

  static addDocument(doc: DocumentRecord) {
    const docs = this.getDocuments();
    const existingIdx = docs.findIndex((d) => d.id === doc.id);
    if (existingIdx >= 0) {
      docs[existingIdx] = doc;
    } else {
      docs.unshift(doc);
    }
    this.saveDocuments(docs);
  }

  static deleteDocument(id: string) {
    const docs = this.getDocuments().filter((d) => d.id !== id);
    this.saveDocuments(docs);
  }

  // Active Document
  static getActiveDocId(): string {
    if (typeof window === 'undefined') return DEMO_DOC_A_CONTRACT.id;
    return localStorage.getItem(STORAGE_KEYS.ACTIVE_DOC_ID) || DEMO_DOC_A_CONTRACT.id;
  }

  static setActiveDocId(id: string) {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_DOC_ID, id);
    }
  }

  // Compare Pair
  static getCompareDocAId(): string {
    if (typeof window === 'undefined') return DEMO_DOC_A_CONTRACT.id;
    return localStorage.getItem(STORAGE_KEYS.COMPARE_DOC_A) || DEMO_DOC_A_CONTRACT.id;
  }

  static setCompareDocAId(id: string) {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.COMPARE_DOC_A, id);
    }
  }

  static getCompareDocBId(): string {
    if (typeof window === 'undefined') return DEMO_DOC_B_CONTRACT.id;
    return localStorage.getItem(STORAGE_KEYS.COMPARE_DOC_B) || DEMO_DOC_B_CONTRACT.id;
  }

  static setCompareDocBId(id: string) {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.COMPARE_DOC_B, id);
    }
  }

  // Stored Comparison Result
  static getComparisonResult(): ComparisonResult {
    if (typeof window === 'undefined') return DEMO_COMPARISON_CONTRACTS;
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.COMPARISON_RESULT);
      if (stored) return JSON.parse(stored);
    } catch {}
    return DEMO_COMPARISON_CONTRACTS;
  }

  static setComparisonResult(res: ComparisonResult) {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.COMPARISON_RESULT, JSON.stringify(res));
    }
  }

  // Conflict Statuses (id -> 'resolved' | 'ignored' | 'important' | 'unresolved')
  static getConflictStatuses(): Record<string, 'resolved' | 'ignored' | 'important' | 'unresolved'> {
    if (typeof window === 'undefined') return {};
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CONFLICT_STATUSES);
      if (stored) return JSON.parse(stored);
    } catch {}
    return {};
  }

  static setConflictStatus(id: string, status: 'resolved' | 'ignored' | 'important' | 'unresolved') {
    if (typeof window !== 'undefined') {
      const map = this.getConflictStatuses();
      map[id] = status;
      localStorage.setItem(STORAGE_KEYS.CONFLICT_STATUSES, JSON.stringify(map));
    }
  }

  // Action Items Completed (id -> boolean)
  static getActionCompletedMap(): Record<string, boolean> {
    if (typeof window === 'undefined') return {};
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ACTION_COMPLETED);
      if (stored) return JSON.parse(stored);
    } catch {}
    return {};
  }

  static toggleActionCompleted(id: string): boolean {
    if (typeof window === 'undefined') return false;
    const map = this.getActionCompletedMap();
    map[id] = !map[id];
    localStorage.setItem(STORAGE_KEYS.ACTION_COMPLETED, JSON.stringify(map));
    return map[id];
  }

  // Smart Alerts
  static getAlerts(): SmartAlert[] {
    if (typeof window === 'undefined') return [];
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ALERTS);
      if (stored) return JSON.parse(stored);
    } catch {}

    const initialAlerts: SmartAlert[] = [
      {
        id: 'alt-1',
        title: 'Deadline Approaching',
        message: 'Contract final application delivery is due on 15 October 2026.',
        category: 'deadline',
        timestamp: 'Just now',
        read: false,
        actionView: 'actions',
      },
      {
        id: 'alt-2',
        title: 'Critical Conflict Detected',
        message: 'Master Services Agreement v1 vs v2 specifies conflicting deadlines (Oct 15 vs Oct 20).',
        category: 'conflict',
        timestamp: '10 mins ago',
        read: false,
        actionView: 'conflicts',
      },
      {
        id: 'alt-3',
        title: 'Priority Fellowship Deadline',
        message: 'Graduate admissions $32,000 stipend consideration closes 15 October 2026.',
        category: 'deadline',
        timestamp: '1 hour ago',
        read: false,
        actionView: 'actions',
      },
      {
        id: 'alt-4',
        title: 'Financial Discrepancy Alert',
        message: 'Contract revision v2 increases remuneration from $45,000 to $58,000 USD.',
        category: 'warning',
        timestamp: '2 hours ago',
        read: true,
        actionView: 'compare',
      },
    ];
    this.saveAlerts(initialAlerts);
    return initialAlerts;
  }

  static saveAlerts(alerts: SmartAlert[]) {
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.ALERTS, JSON.stringify(alerts));
    }
  }

  static markAlertRead(id: string) {
    const alerts = this.getAlerts().map((a) => (a.id === id ? { ...a, read: true } : a));
    this.saveAlerts(alerts);
  }

  // Clear ALL Local Data
  static clearAllData() {
    if (typeof window !== 'undefined') {
      Object.values(STORAGE_KEYS).forEach((key) => {
        localStorage.removeItem(key);
      });
    }
  }

  // Calculate storage usage
  static getStorageFootprint(): { count: number; estimatedKb: number } {
    if (typeof window === 'undefined') return { count: 0, estimatedKb: 0 };
    let totalBytes = 0;
    let count = 0;
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('documind_')) {
        count++;
        const val = localStorage.getItem(key) || '';
        totalBytes += key.length + val.length;
      }
    }
    return {
      count,
      estimatedKb: Math.round((totalBytes / 1024) * 10) / 10,
    };
  }
}
