import React from 'react';
import {
  LayoutDashboard,
  Files,
  Search,
  GitCompare,
  AlertTriangle,
  CheckSquare,
  Bell,
  Volume2,
  Globe,
  ShieldCheck,
  FileText,
  Lock,
  Zap,
} from 'lucide-react';
import { NavView, AppMode, Language } from '../types';
import { getTranslation } from '../utils/i18n';

interface SidebarProps {
  currentView: NavView;
  onNavigate: (view: NavView) => void;
  activeMode: AppMode;
  language: Language;
  conflictCount: number;
  deadlineCount: number;
  alertCount: number;
  onOpenModeSelect: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  activeMode,
  language,
  conflictCount,
  deadlineCount,
  alertCount,
  onOpenModeSelect,
}) => {
  const t = (key: string) => getTranslation(language, key);

  const navItems: Array<{
    id: NavView;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
    badgeColor?: string;
  }> = [
    { id: 'dashboard', label: t('dashboard'), icon: LayoutDashboard },
    { id: 'documents', label: t('documents'), icon: Files },
    { id: 'analyze', label: t('analyze'), icon: Search },
    { id: 'compare', label: t('compare'), icon: GitCompare },
    {
      id: 'conflicts',
      label: t('conflicts'),
      icon: AlertTriangle,
      badge: conflictCount,
      badgeColor: 'bg-red-500/20 text-red-300 border-red-500/30',
    },
    {
      id: 'actions',
      label: t('actionItems'),
      icon: CheckSquare,
      badge: deadlineCount,
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    },
    {
      id: 'alerts',
      label: t('alerts'),
      icon: Bell,
      badge: alertCount,
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    },
    { id: 'voice', label: t('voice'), icon: Volume2 },
    { id: 'privacy', label: t('privacySettings'), icon: ShieldCheck },
  ];

  return (
    <aside className="w-64 bg-slate-950 border-r border-slate-800/80 flex flex-col justify-between shrink-0 select-none">
      {/* Brand Header */}
      <div>
        <div className="h-16 px-6 flex items-center gap-3 border-b border-slate-800/80">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <FileText className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-base font-extrabold tracking-tight text-white leading-tight">DocuMind</h1>
            <p className="text-[10px] text-slate-400 font-medium">Smart Document Analyzer</p>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="p-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900/80'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && item.badge > 0 && (
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md border ${
                      isActive ? 'bg-white/20 text-white border-white/30' : item.badgeColor
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Mode Status Footer Card */}
      <div className="p-4 border-t border-slate-900">
        <div
          onClick={onOpenModeSelect}
          className={`p-3.5 rounded-2xl border transition-all cursor-pointer group ${
            activeMode === 'offline'
              ? 'bg-emerald-950/30 border-emerald-500/30 hover:border-emerald-500/60'
              : 'bg-blue-950/30 border-blue-500/30 hover:border-blue-500/60'
          }`}
        >
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Active Engine
            </span>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                activeMode === 'offline'
                  ? 'bg-emerald-500/20 text-emerald-300'
                  : 'bg-blue-500/20 text-blue-300'
              }`}
            >
              {activeMode === 'offline' ? <Lock className="w-2.5 h-2.5" /> : <Zap className="w-2.5 h-2.5" />}
              {activeMode === 'offline' ? 'Offline' : 'Online'}
            </span>
          </div>
          <p className="text-xs font-semibold text-slate-200">
            {activeMode === 'offline' ? 'On-Device Privacy Engine' : 'Gemini 3.8 Flash Cloud'}
          </p>
          <p className="text-[10px] text-slate-400 mt-1 group-hover:text-slate-200 transition-colors">
            Click to switch mode anytime →
          </p>
        </div>
      </div>
    </aside>
  );
};
