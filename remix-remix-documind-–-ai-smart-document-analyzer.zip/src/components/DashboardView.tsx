import React from 'react';
import { motion } from 'motion/react';
import {
  FileText,
  AlertTriangle,
  Calendar,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Zap,
  Lock,
  Upload,
  GitCompare,
  Mic,
  CheckCircle2,
  Clock,
  Eye,
} from 'lucide-react';
import { DocumentRecord, AppMode, Language, ConflictItem, NavView } from '../types';
import { getTranslation } from '../utils/i18n';

interface DashboardViewProps {
  documents: DocumentRecord[];
  activeMode: AppMode;
  privacyMode: boolean;
  language: Language;
  onNavigate: (view: NavView) => void;
  onSelectDoc: (id: string) => void;
  onLoadDemoContracts: () => void;
  conflicts: ConflictItem[];
  onResolveConflict: (id: string) => void;
  onToggleActionItem: (id: string) => void;
  actionCompletedMap: Record<string, boolean>;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  documents,
  activeMode,
  privacyMode,
  language,
  onNavigate,
  onSelectDoc,
  onLoadDemoContracts,
  conflicts,
  onResolveConflict,
  onToggleActionItem,
  actionCompletedMap,
}) => {
  const t = (key: string) => getTranslation(language, key);

  // Compute stats
  const totalDocs = documents.length;
  const unresolvedConflicts = conflicts.filter((c) => c.status === 'unresolved').length;
  
  // Aggregate deadlines across documents
  const allDeadlines = documents.flatMap((d) => d.analysis?.deadlines || []);
  const upcomingDeadlinesCount = allDeadlines.length;

  // Average clarity score
  const docsWithScore = documents.filter((d) => d.analysis?.clarityScore);
  const avgClarity =
    docsWithScore.length > 0
      ? Math.round(
          docsWithScore.reduce((acc, d) => acc + (d.analysis?.clarityScore || 0), 0) /
            docsWithScore.length
        )
      : 84;

  // Aggregate action items
  const allActions = documents.flatMap((d) => d.analysis?.actionItems || []).slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Top Welcome / Status Hero */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 p-6 sm:p-8 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Workspace Live
              </span>
              <span
                className={`px-2.5 py-1 rounded-full text-[11px] font-bold flex items-center gap-1.5 border ${
                  activeMode === 'offline'
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                    : 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                }`}
              >
                {activeMode === 'offline' ? <Lock className="w-3 h-3" /> : <Zap className="w-3 h-3" />}
                {activeMode === 'offline' ? 'Offline Mode Active' : 'Online Mode (Gemini 3.8 Flash)'}
              </span>
              {privacyMode && (
                <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-950/50 text-emerald-300 border border-emerald-500/30 hidden sm:inline-flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Privacy Guard ON
                </span>
              )}
            </div>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              DocuMind Intelligence Center
            </h2>
            <p className="mt-1 text-sm text-slate-400 max-w-xl">
              “Understand Documents. Detect What Matters. Take Action.” Review contracts, resolve contradictions, and monitor upcoming deadlines.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('documents')}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-blue-600 hover:from-indigo-600 hover:to-blue-700 text-white font-semibold text-xs shadow-md shadow-indigo-600/30 flex items-center gap-2 cursor-pointer transition-all"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>{t('uploadDocument')}</span>
            </button>

            <button
              onClick={onLoadDemoContracts}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-semibold text-xs flex items-center gap-2 cursor-pointer transition-all"
            >
              <GitCompare className="w-3.5 h-3.5 text-purple-400" />
              <span>Load Sample Comparison</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4 Stat Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div
          onClick={() => onNavigate('documents')}
          className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Documents Analyzed</span>
            <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-white group-hover:text-blue-400 transition-colors">
            {totalDocs}
          </div>
          <p className="mt-1 text-[11px] text-slate-400">Available in local workspace</p>
        </div>

        {/* Metric 2 */}
        <div
          onClick={() => onNavigate('conflicts')}
          className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-red-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Detected Conflicts</span>
            <div className="w-8 h-8 rounded-xl bg-red-500/10 text-red-400 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-red-400">
            {unresolvedConflicts}
          </div>
          <p className="mt-1 text-[11px] text-slate-400">
            {unresolvedConflicts > 0 ? 'Requires your review & alignment' : 'All contradictions resolved'}
          </p>
        </div>

        {/* Metric 3 */}
        <div
          onClick={() => onNavigate('actions')}
          className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-emerald-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Deadlines Tracked</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-emerald-400">
            {upcomingDeadlinesCount}
          </div>
          <p className="mt-1 text-[11px] text-slate-400">Next cutoff: 15 October 2026</p>
        </div>

        {/* Metric 4 */}
        <div
          onClick={() => onNavigate('analyze')}
          className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold uppercase tracking-wider">Avg Clarity Score</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-indigo-400">
            {avgClarity}/100
          </div>
          <p className="mt-1 text-[11px] text-slate-400">High readability benchmark</p>
        </div>
      </div>

      {/* Main Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Recent Documents Table (2 spans) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-400" />
                <h3 className="text-base font-bold text-white">Active Document Vault</h3>
              </div>
              <button
                onClick={() => onNavigate('documents')}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1 cursor-pointer"
              >
                <span>View All ({documents.length})</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {documents.slice(0, 4).map((doc) => (
                <div
                  key={doc.id}
                  onClick={() => {
                    onSelectDoc(doc.id);
                    onNavigate('analyze');
                  }}
                  className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-indigo-500/50 hover:bg-slate-950 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer group"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 mt-0.5">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                        {doc.title}
                      </h4>
                      <div className="flex flex-wrap items-center gap-2 mt-1 text-[11px] text-slate-400">
                        <span>{doc.fileName}</span>
                        <span>•</span>
                        <span>{(doc.fileSize / 1024).toFixed(1)} KB</span>
                        <span>•</span>
                        <span className="text-emerald-400 font-medium">
                          {doc.analysis?.wordCount || 300} words
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    {doc.analysis?.clarityScore && (
                      <span className="text-xs font-bold px-2 py-1 rounded-lg bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                        Score: {doc.analysis.clarityScore}
                      </span>
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectDoc(doc.id);
                        onNavigate('analyze');
                      }}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-indigo-600 text-slate-300 hover:text-white transition-colors"
                      title="Analyze this document"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Urgent Conflicts Ticker */}
          <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400" />
                <h3 className="text-base font-bold text-white">Detected Contradictions</h3>
              </div>
              <button
                onClick={() => onNavigate('conflicts')}
                className="text-xs text-red-400 hover:text-red-300 font-semibold flex items-center gap-1 cursor-pointer"
              >
                <span>View Conflicts Center</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {conflicts.slice(0, 3).map((conflict) => {
                const isResolved = conflict.status === 'resolved';
                return (
                  <div
                    key={conflict.id}
                    className={`p-4 rounded-2xl border transition-all ${
                      isResolved
                        ? 'bg-slate-950/40 border-slate-800 opacity-60'
                        : 'bg-red-950/20 border-red-500/30'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs font-semibold mb-2">
                      <span className="text-red-400 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
                        {conflict.title}
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-300">
                        Category: {conflict.category}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono mt-2">
                      <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-300">
                        <span className="text-slate-500 block text-[9px] uppercase">Document A</span>
                        {conflict.docAQuote}
                      </div>
                      <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-300">
                        <span className="text-slate-500 block text-[9px] uppercase">Document B</span>
                        {conflict.docBQuote}
                      </div>
                    </div>

                    <div className="mt-3 flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs">
                      <p className="text-[11px] text-slate-400 truncate max-w-sm">
                        {conflict.explanation}
                      </p>
                      <button
                        onClick={() => onResolveConflict(conflict.id)}
                        className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                          isResolved
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-red-600 hover:bg-red-500 text-white'
                        }`}
                      >
                        {isResolved ? 'Resolved ✓' : 'Mark Resolved'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Action Items & Fast Actions (1 span) */}
        <div className="space-y-6">
          {/* Action Checklist */}
          <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <h3 className="text-base font-bold text-white">Action Items</h3>
              </div>
              <button
                onClick={() => onNavigate('actions')}
                className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold cursor-pointer"
              >
                All Tasks →
              </button>
            </div>

            <p className="text-xs text-slate-400 mb-4">
              Automatically extracted actionable commitments from uploaded documents:
            </p>

            <div className="space-y-2.5">
              {allActions.map((item) => {
                const isCompleted = actionCompletedMap[item.id] ?? item.completed ?? false;
                return (
                  <div
                    key={item.id}
                    onClick={() => onToggleActionItem(item.id)}
                    className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 transition-all cursor-pointer select-none ${
                      isCompleted
                        ? 'bg-slate-950/40 border-slate-800 line-through text-slate-500'
                        : 'bg-slate-950/80 border-slate-800 text-slate-200 hover:border-slate-700'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isCompleted}
                      onChange={() => onToggleActionItem(item.id)}
                      className="mt-0.5 accent-emerald-500 cursor-pointer"
                    />
                    <div className="flex-1">
                      <p className="font-medium leading-snug">{item.task}</p>
                      {item.deadline && (
                        <div className="flex items-center gap-1.5 mt-1 text-[10px] text-amber-400">
                          <Clock className="w-2.5 h-2.5" />
                          <span>Due: {item.deadline}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Voice Hub Widget */}
          <div className="rounded-3xl bg-gradient-to-br from-violet-950/40 via-slate-900 to-indigo-950/30 border border-violet-800/40 p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-2xl bg-violet-500/20 border border-violet-500/30 text-violet-400 flex items-center justify-center">
                <Mic className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Voice Assistant</h4>
                <p className="text-[11px] text-slate-400">Speech-to-Text & Narration</p>
              </div>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              Try voice commands like: <br />
              <span className="text-violet-300 italic font-mono text-[11px]">
                “Show important deadlines” • “Read summary” • “Check conflicts”
              </span>
            </p>
            <button
              onClick={() => onNavigate('voice')}
              className="w-full py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-semibold text-xs shadow-md transition-all cursor-pointer"
            >
              Open Voice Studio
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
