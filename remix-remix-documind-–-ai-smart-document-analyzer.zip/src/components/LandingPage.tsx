import React from 'react';
import { motion } from 'motion/react';
import {
  FileText,
  Shield,
  Zap,
  GitCompare,
  AlertTriangle,
  Bell,
  Volume2,
  Globe,
  ArrowRight,
  Sparkles,
  Lock,
  Cpu,
  Layers,
  CheckCircle2,
} from 'lucide-react';
import { Language, AppMode } from '../types';
import { getTranslation, SUPPORTED_LANGUAGES } from '../utils/i18n';

interface LandingPageProps {
  onGetStarted: () => void;
  onTryOffline: () => void;
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onGetStarted,
  onTryOffline,
  currentLanguage,
  onLanguageChange,
}) => {
  const t = (key: string) => getTranslation(currentLanguage, key);

  const features = [
    {
      icon: Cpu,
      title: 'AI Document Analysis',
      desc: 'Instant synthesis of dense files into executive summaries, key entities, and structured insights.',
      color: 'from-blue-500/20 to-indigo-500/20 border-blue-500/30 text-blue-600 dark:text-blue-400',
    },
    {
      icon: Zap,
      title: 'Offline & Online Mode',
      desc: 'Seamless dual-architecture. Run entirely on-device with zero internet or tap Gemini 3.8 Flash online.',
      color: 'from-emerald-500/20 to-teal-500/20 border-emerald-500/30 text-emerald-600 dark:text-emerald-400',
    },
    {
      icon: Shield,
      title: 'Privacy Protection',
      desc: 'Your confidential agreements never leave your browser sandbox unless explicitly enabled.',
      color: 'from-amber-500/20 to-orange-500/20 border-amber-500/30 text-amber-600 dark:text-amber-400',
    },
    {
      icon: GitCompare,
      title: 'Document Comparison',
      desc: 'Side-by-side diffing highlighting additions, deletions, modified clauses, and changed amounts.',
      color: 'from-purple-500/20 to-pink-500/20 border-purple-500/30 text-purple-600 dark:text-purple-400',
    },
    {
      icon: AlertTriangle,
      title: 'Conflict Detection',
      desc: 'Autonomous discovery of contradictory deadlines (e.g. Oct 15 vs Oct 20) and conflicting fee schedules.',
      color: 'from-red-500/20 to-rose-500/20 border-red-500/30 text-red-600 dark:text-red-400',
    },
    {
      icon: Bell,
      title: 'Smart Alerts',
      desc: 'Autonomous milestone alerts, urgent deadline warnings, and synthesized notification chimes.',
      color: 'from-cyan-500/20 to-sky-500/20 border-cyan-500/30 text-cyan-600 dark:text-cyan-400',
    },
    {
      icon: Volume2,
      title: 'Voice Interaction',
      desc: 'Voice commands for hands-free queries and multilingual text-to-speech narration with rate control.',
      color: 'from-violet-500/20 to-fuchsia-500/20 border-violet-500/30 text-violet-600 dark:text-violet-400',
    },
    {
      icon: Globe,
      title: 'Multilingual Support',
      desc: 'Native support for English, Hindi, Tamil, Telugu, Malayalam, and Kannada.',
      color: 'from-teal-500/20 to-emerald-500/20 border-teal-500/30 text-teal-600 dark:text-teal-400',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-indigo-500 selection:text-white relative overflow-hidden">
      {/* Background Glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[550px] bg-gradient-to-b from-indigo-600/20 via-blue-600/10 to-transparent blur-3xl pointer-events-none rounded-full" />
      <div className="absolute top-1/3 -left-48 w-96 h-96 bg-purple-600/15 blur-3xl pointer-events-none rounded-full" />
      <div className="absolute top-1/2 -right-48 w-96 h-96 bg-emerald-600/15 blur-3xl pointer-events-none rounded-full" />

      {/* Navigation Header */}
      <header className="relative z-10 max-w-7xl mx-auto px-6 py-6 flex items-center justify-between border-b border-slate-800/60 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 flex items-center justify-center shadow-lg shadow-indigo-500/25 ring-1 ring-white/20">
            <FileText className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-xl tracking-tight text-white">DocuMind</span>
              <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                v1.0 AI
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">AI Smart Document Analyzer</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          {/* Language selector in landing page */}
          <div className="relative flex items-center gap-1.5 bg-slate-900/90 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-300">
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={currentLanguage}
              onChange={(e) => onLanguageChange(e.target.value as Language)}
              aria-label="Select interface language"
              className="bg-transparent text-xs text-slate-200 outline-none cursor-pointer pr-1"
            >
              {SUPPORTED_LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.code} className="bg-slate-900 text-slate-200">
                  {lang.nativeName} ({lang.name})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={onTryOffline}
            className="text-xs font-semibold px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-slate-200 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">{t('tryOfflineMode')}</span>
            <span className="sm:hidden">Offline</span>
          </button>

          <button
            onClick={onGetStarted}
            className="text-xs font-semibold px-4 py-2 rounded-lg bg-gradient-to-r from-indigo-500 to-blue-600 hover:from-indigo-600 hover:to-blue-700 text-white shadow-md shadow-indigo-500/25 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <span>{t('getStarted')}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <main className="relative z-10 max-w-7xl mx-auto px-6 pt-16 pb-24 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-950/70 border border-indigo-800/60 text-indigo-300 text-xs font-medium mb-8 backdrop-blur-sm shadow-inner"
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>Next-Gen Document Intelligence • Privacy First</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white max-w-5xl mx-auto leading-tight"
        >
          DocuMind
          <span className="block text-2xl sm:text-3xl lg:text-4xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-sky-300 to-teal-300 mt-2">
            AI Smart Document Analyzer
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-6 text-xl sm:text-2xl font-medium text-indigo-200/90 max-w-3xl mx-auto italic"
        >
          “Understand Documents. Detect What Matters. Take Action.”
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-5 text-sm sm:text-base text-slate-400 max-w-2xl mx-auto leading-relaxed"
        >
          {t('heroDescription')}
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <button
            onClick={onGetStarted}
            className="px-8 py-3.5 rounded-xl bg-gradient-to-r from-indigo-500 via-indigo-600 to-blue-600 hover:from-indigo-600 hover:to-blue-700 text-white font-semibold text-sm shadow-xl shadow-indigo-600/30 hover:shadow-indigo-600/50 hover:scale-[1.02] transition-all flex items-center gap-2 cursor-pointer ring-1 ring-white/20"
          >
            <span>{t('getStarted')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onTryOffline}
            className="px-7 py-3.5 rounded-xl bg-slate-900/90 hover:bg-slate-800/90 border border-slate-700 text-slate-200 font-semibold text-sm hover:scale-[1.02] transition-all flex items-center gap-2 cursor-pointer shadow-lg shadow-black/40"
          >
            <Lock className="w-4 h-4 text-emerald-400" />
            <span>{t('tryOfflineMode')}</span>
          </button>
        </motion.div>

        {/* Live Teaser Preview Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="mt-14 max-w-4xl mx-auto rounded-2xl border border-slate-800 bg-slate-900/80 p-5 sm:p-6 backdrop-blur-xl shadow-2xl text-left"
        >
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-4 mb-5">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
              <span className="ml-2 text-xs font-mono text-slate-400">documind-analyzer-engine v1.0</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-medium">
                <Shield className="w-3 h-3" /> Privacy Sandbox Active
              </span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/30 font-medium">
                <Cpu className="w-3 h-3" /> Gemini 3.8 Flash Ready
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Box 1: Conflict Detected */}
            <div className="p-4 rounded-xl bg-slate-950/70 border border-red-500/30">
              <div className="flex items-center justify-between text-xs font-semibold text-red-400 mb-2">
                <span className="flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" /> Conflict Detected
                </span>
                <span className="px-1.5 py-0.5 rounded bg-red-500/20 text-[10px]">High</span>
              </div>
              <p className="text-xs text-slate-300 font-medium">Deadline Contradiction</p>
              <div className="mt-2 text-[11px] space-y-1 font-mono text-slate-400">
                <p className="text-red-300/90 bg-red-950/40 px-2 py-1 rounded border-l-2 border-red-500">
                  Doc A: "Deadline 15 October 2026"
                </p>
                <p className="text-amber-300/90 bg-amber-950/40 px-2 py-1 rounded border-l-2 border-amber-500">
                  Doc B: "Deadline 20 October 2026"
                </p>
              </div>
            </div>

            {/* Box 2: Clarity Score */}
            <div className="p-4 rounded-xl bg-slate-950/70 border border-indigo-500/30">
              <div className="flex items-center justify-between text-xs font-semibold text-indigo-400 mb-2">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> Clarity Score
                </span>
                <span className="text-base font-bold text-white">88/100</span>
              </div>
              <p className="text-xs text-slate-300 font-medium">High Clarity Document</p>
              <div className="mt-2.5 space-y-1.5">
                <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                  <div className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-2 rounded-full w-[88%]" />
                </div>
                <p className="text-[11px] text-slate-400">2 Ambiguous clauses flagged for review</p>
              </div>
            </div>

            {/* Box 3: Action Items */}
            <div className="p-4 rounded-xl bg-slate-950/70 border border-emerald-500/30">
              <div className="flex items-center justify-between text-xs font-semibold text-emerald-400 mb-2">
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Extracted Tasks
                </span>
                <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-[10px]">3 Action Items</span>
              </div>
              <div className="text-[11px] space-y-1.5 text-slate-300">
                <div className="flex items-center gap-2">
                  <span className="text-emerald-400">☑</span> Submit application by 15 Oct
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-emerald-400">☑</span> Attend weekly architectural call
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-emerald-400">☑</span> Upload compliance certification
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Feature Cards Grid (8 Core Features) */}
        <div className="mt-28">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
              Engineered for Complete Document Mastery
            </h2>
            <p className="mt-3 text-sm sm:text-base text-slate-400">
              Every tool required to extract truth, verify commitments, and protect your privacy.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {features.map((feat, index) => {
              const Icon = feat.icon;
              return (
                <motion.div
                  key={feat.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.05 }}
                  className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 text-left hover:border-slate-700 hover:bg-slate-900 transition-all group backdrop-blur-sm"
                >
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 border bg-gradient-to-br ${feat.color}`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-white group-hover:text-indigo-300 transition-colors">
                    {feat.title}
                  </h3>
                  <p className="mt-2 text-xs leading-relaxed text-slate-400">{feat.desc}</p>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Bottom Banner */}
        <div className="mt-24 p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-indigo-950/80 via-slate-900 to-blue-950/80 border border-indigo-800/50 backdrop-blur-md relative overflow-hidden text-center">
          <div className="relative z-10 max-w-2xl mx-auto">
            <h3 className="text-2xl sm:text-3xl font-extrabold text-white">
              Ready to analyze your first document?
            </h3>
            <p className="mt-3 text-sm text-slate-300">
              Explore pre-loaded contract revisions with built-in deadline conflicts, or upload your own files safely.
            </p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
              <button
                onClick={onGetStarted}
                className="px-8 py-3 rounded-xl bg-white hover:bg-slate-100 text-slate-950 font-bold text-sm shadow-xl transition-all cursor-pointer"
              >
                Launch DocuMind Workspace
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-slate-900 py-8 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 2026 DocuMind. All rights reserved. “Understand Documents. Detect What Matters. Take Action.”</p>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Privacy-First Architecture</span>
            <span>•</span>
            <span>Web Speech API</span>
            <span>•</span>
            <span>Gemini 3.8 Flash</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
