import React, { useState } from 'react';
import {
  Search,
  Globe,
  Bell,
  Lock,
  Zap,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  User,
  ShieldCheck,
  ChevronDown,
} from 'lucide-react';
import { AppMode, Language, SmartAlert } from '../types';
import { getTranslation, SUPPORTED_LANGUAGES } from '../utils/i18n';

interface TopNavProps {
  currentMode: AppMode;
  onToggleMode: () => void;
  privacyMode: boolean;
  onTogglePrivacy: () => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  alerts: SmartAlert[];
  onOpenAlerts: () => void;
  soundMuted: boolean;
  onToggleSound: () => void;
  isListening: boolean;
  onToggleVoiceCommand: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  currentMode,
  onToggleMode,
  privacyMode,
  onTogglePrivacy,
  language,
  onLanguageChange,
  searchQuery,
  onSearchChange,
  alerts,
  onOpenAlerts,
  soundMuted,
  onToggleSound,
  isListening,
  onToggleVoiceCommand,
}) => {
  const t = (key: string) => getTranslation(language, key);
  const unreadAlerts = alerts.filter((a) => !a.read).length;
  const [langMenuOpen, setLangMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 h-16 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 px-4 sm:px-6 flex items-center justify-between gap-4">
      {/* Search Input */}
      <div className="flex-1 max-w-md relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
          <Search className="w-4 h-4" />
        </div>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={t('searchPlaceholder')}
          className="w-full bg-slate-950/80 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
        />
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Mode Indicator & Switcher Button */}
        <button
          onClick={onToggleMode}
          title="Click to toggle between Offline and Online mode"
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
            currentMode === 'offline'
              ? 'bg-emerald-950/50 text-emerald-300 border-emerald-500/40 hover:bg-emerald-900/50'
              : 'bg-blue-950/50 text-blue-300 border-blue-500/40 hover:bg-blue-900/50'
          }`}
        >
          {currentMode === 'offline' ? (
            <>
              <Lock className="w-3.5 h-3.5 text-emerald-400" />
              <span>Offline</span>
            </>
          ) : (
            <>
              <Zap className="w-3.5 h-3.5 text-blue-400" />
              <span>Online</span>
            </>
          )}
        </button>

        {/* Privacy Mode Toggle Badge */}
        <button
          onClick={onTogglePrivacy}
          title={privacyMode ? 'Privacy Mode is Active' : 'Privacy Mode is Off'}
          className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
            privacyMode
              ? 'bg-indigo-950/50 text-indigo-300 border-indigo-500/40 hover:bg-indigo-900/50'
              : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
          <span>{privacyMode ? 'Privacy ON' : 'Privacy OFF'}</span>
        </button>

        {/* Voice Command Mic Button */}
        <button
          onClick={onToggleVoiceCommand}
          title={isListening ? 'Listening for command...' : 'Voice command listener'}
          className={`p-2 rounded-xl border text-xs transition-all relative cursor-pointer ${
            isListening
              ? 'bg-red-500/20 text-red-400 border-red-500/40 animate-pulse'
              : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white hover:bg-slate-800'
          }`}
        >
          {isListening ? <Mic className="w-4 h-4 text-red-400" /> : <Mic className="w-4 h-4" />}
          {isListening && (
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-red-500 rounded-full animate-ping" />
          )}
        </button>

        {/* Sound Toggle Button */}
        <button
          onClick={onToggleSound}
          title={soundMuted ? 'Unmute alert sound' : 'Mute alert sound'}
          className="p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          {soundMuted ? <VolumeX className="w-4 h-4 text-slate-500" /> : <Volume2 className="w-4 h-4 text-indigo-400" />}
        </button>

        {/* Language Dropdown */}
        <div className="relative">
          <button
            onClick={() => setLangMenuOpen(!langMenuOpen)}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-medium text-slate-300 hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <span className="hidden sm:inline">
              {SUPPORTED_LANGUAGES.find((l) => l.code === language)?.nativeName || 'EN'}
            </span>
            <ChevronDown className="w-3 h-3 text-slate-500" />
          </button>

          {langMenuOpen && (
            <div className="absolute right-0 mt-2 w-44 rounded-xl bg-slate-900 border border-slate-800 shadow-xl py-1 z-50">
              {SUPPORTED_LANGUAGES.map((l) => (
                <button
                  key={l.code}
                  onClick={() => {
                    onLanguageChange(l.code);
                    setLangMenuOpen(false);
                  }}
                  className={`w-full text-left px-3.5 py-2 text-xs flex items-center justify-between transition-colors cursor-pointer ${
                    language === l.code
                      ? 'bg-indigo-600/20 text-indigo-300 font-bold'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span>{l.nativeName}</span>
                  <span className="text-[10px] text-slate-500">{l.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Notification Bell */}
        <button
          onClick={onOpenAlerts}
          title="Open Smart Alerts"
          className="relative p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <Bell className="w-4 h-4" />
          {unreadAlerts > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-indigo-500 text-white rounded-full text-[10px] font-bold flex items-center justify-center">
              {unreadAlerts}
            </span>
          )}
        </button>

        {/* User Profile */}
        <div className="flex items-center gap-2 pl-1 border-l border-slate-800">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold shadow-md shadow-indigo-500/20">
            <User className="w-4 h-4" />
          </div>
        </div>
      </div>
    </header>
  );
};
