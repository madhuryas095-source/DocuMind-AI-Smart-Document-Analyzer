import React, { useState } from 'react';
import {
  GitCompare,
  PlusCircle,
  MinusCircle,
  Edit3,
  AlertTriangle,
  Calendar,
  DollarSign,
  CheckCircle2,
  Volume2,
  RefreshCw,
  Sparkles,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { DocumentRecord, ComparisonResult, AppMode, Language } from '../types';
import { getTranslation } from '../utils/i18n';
import { voiceEngine } from '../utils/voice';

interface CompareViewProps {
  documents: DocumentRecord[];
  docAId: string;
  docBId: string;
  onSelectDocA: (id: string) => void;
  onSelectDocB: (id: string) => void;
  comparisonResult: ComparisonResult;
  onRunComparison: () => void;
  isComparing: boolean;
  activeMode: AppMode;
  language: Language;
  onNavigateToConflicts: () => void;
}

export const CompareView: React.FC<CompareViewProps> = ({
  documents,
  docAId,
  docBId,
  onSelectDocA,
  onSelectDocB,
  comparisonResult,
  onRunComparison,
  isComparing,
  activeMode,
  language,
  onNavigateToConflicts,
}) => {
  const t = (key: string) => getTranslation(language, key);
  const [speechPlaying, setSpeechPlaying] = useState(false);
  const [activeTab, setActiveTab] = useState<'summary' | 'dates' | 'amounts' | 'requirements' | 'changes'>('summary');

  const docA = documents.find((d) => d.id === docAId) || documents[0];
  const docB = documents.find((d) => d.id === docBId) || documents[1] || documents[0];

  const handleSpeakSummary = () => {
    if (speechPlaying) {
      voiceEngine.stop();
      setSpeechPlaying(false);
    } else {
      voiceEngine.speak(
        comparisonResult.comparisonSummary,
        language,
        () => setSpeechPlaying(false),
        () => setSpeechPlaying(false)
      );
      setSpeechPlaying(true);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header and Document Pickers */}
      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/10 border border-purple-500/20 text-purple-300 mb-2">
              <GitCompare className="w-3.5 h-3.5" />
              <span>Comparative Diff Engine</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              {t('comparisonTitle')}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Select two document versions to detect modifications, timeline shifts, and legal contradictions.
            </p>
          </div>

          <button
            onClick={onRunComparison}
            disabled={isComparing}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs flex items-center gap-2 shadow-md shadow-purple-600/30 transition-all cursor-pointer disabled:opacity-50 self-start sm:self-center"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isComparing ? 'animate-spin' : ''}`} />
            <span>{isComparing ? 'Comparing...' : 'Run Deep Comparison'}</span>
          </button>
        </div>

        {/* Side-by-side Document Selectors */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-800">
          {/* Doc A Picker */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
              Document A (Base Version)
            </span>
            <select
              value={docA?.id}
              onChange={(e) => onSelectDocA(e.target.value)}
              aria-label="Select base document (Document A)"
              className="w-full bg-slate-900 border border-slate-700 text-xs text-white rounded-xl px-3 py-2 outline-none cursor-pointer"
            >
              {documents.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.title}
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-500 mt-2 truncate">
              {docA?.fileName} • {docA?.analysis?.wordCount || 0} words
            </p>
          </div>

          {/* Doc B Picker */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
              Document B (Revised Version)
            </span>
            <select
              value={docB?.id}
              onChange={(e) => onSelectDocB(e.target.value)}
              aria-label="Select revised document (Document B)"
              className="w-full bg-slate-900 border border-slate-700 text-xs text-white rounded-xl px-3 py-2 outline-none cursor-pointer"
            >
              {documents.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.title}
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-500 mt-2 truncate">
              {docB?.fileName} • {docB?.analysis?.wordCount || 0} words
            </p>
          </div>
        </div>
      </div>

      {/* Comparison Summary Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-purple-950/30 via-slate-900 to-indigo-950/30 border border-purple-800/40 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-400" />
            <h3 className="text-base font-bold text-white">Executive Comparison Summary</h3>
          </div>
          <button
            onClick={handleSpeakSummary}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors cursor-pointer self-start sm:self-auto"
          >
            <Volume2 className="w-3.5 h-3.5 text-purple-400" />
            <span>{speechPlaying ? 'Stop Audio' : 'Listen to Diff Summary'}</span>
          </button>
        </div>
        <p className="text-sm text-slate-300 leading-relaxed font-sans">
          {comparisonResult.comparisonSummary}
        </p>

        {/* Conflicts Warning Ticker inside Comparison */}
        {comparisonResult.conflicts && comparisonResult.conflicts.length > 0 && (
          <div className="mt-5 p-4 rounded-2xl bg-red-950/30 border border-red-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
              <div>
                <p className="text-xs font-bold text-red-300">
                  {comparisonResult.conflicts.length} Critical Contradictions Detected!
                </p>
                <p className="text-[11px] text-slate-300">
                  Direct deadline conflicts (Oct 15 vs 20) and pricing mismatches require review.
                </p>
              </div>
            </div>
            <button
              onClick={onNavigateToConflicts}
              className="px-3.5 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer self-start sm:self-auto"
            >
              <span>Inspect Conflicts Center</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'summary', label: 'Detailed Diff Indicators' },
          { id: 'dates', label: `Conflicting Dates (${comparisonResult.differentDates?.length || 0})` },
          { id: 'amounts', label: `Changed Amounts (${comparisonResult.differentAmounts?.length || 0})` },
          { id: 'requirements', label: `Modified Requirements (${comparisonResult.changedRequirements?.length || 0})` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              activeTab === tab.id
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab 1: Detailed Diff Indicators (Added, Removed, Modified) */}
      {activeTab === 'summary' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Added Information (Green) */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-emerald-500/30 space-y-4">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
              <PlusCircle className="w-4 h-4" />
              <span>{t('addedInfo')}</span>
            </div>
            <p className="text-xs text-slate-400">
              Clauses and conditions newly introduced in Document B:
            </p>
            <ul className="space-y-2.5">
              {comparisonResult.addedInformation?.map((item, idx) => (
                <li
                  key={idx}
                  className="p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/20 text-xs text-emerald-200/90 leading-snug"
                >
                  <span className="font-bold text-emerald-400 mr-1">+</span> {item}
                </li>
              ))}
            </ul>
          </div>

          {/* Removed Information (Red) */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-rose-500/30 space-y-4">
            <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
              <MinusCircle className="w-4 h-4" />
              <span>{t('removedInfo')}</span>
            </div>
            <p className="text-xs text-slate-400">
              Clauses present in Document A that were omitted in Document B:
            </p>
            <ul className="space-y-2.5">
              {comparisonResult.removedInformation?.map((item, idx) => (
                <li
                  key={idx}
                  className="p-3 rounded-xl bg-rose-950/20 border border-rose-500/20 text-xs text-rose-200/90 leading-snug"
                >
                  <span className="font-bold text-rose-400 mr-1">-</span> {item}
                </li>
              ))}
            </ul>
          </div>

          {/* Modified Information (Amber / Blue) */}
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-amber-500/30 space-y-4">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <Edit3 className="w-4 h-4" />
              <span>{t('modifiedInfo')}</span>
            </div>
            <p className="text-xs text-slate-400">
              Clauses or deliverables with adjusted terms between revisions:
            </p>
            <ul className="space-y-2.5">
              {comparisonResult.modifiedInformation?.map((item, idx) => (
                <li
                  key={idx}
                  className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/20 text-xs text-amber-200/90 leading-snug"
                >
                  <span className="font-bold text-amber-400 mr-1">~</span> {item}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Tab 2: Conflicting Dates */}
      {activeTab === 'dates' && (
        <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8">
          <h3 className="text-base font-bold text-white mb-4">Milestone Timeline Diffs</h3>
          <div className="divide-y divide-slate-800">
            {comparisonResult.differentDates?.map((d, i) => (
              <div key={i} className="py-4 first:pt-0 last:pb-0">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-bold text-white text-sm">{d.topic}</span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                      d.severity === 'critical'
                        ? 'bg-red-500/20 text-red-300'
                        : 'bg-amber-500/20 text-amber-300'
                    }`}
                  >
                    {d.severity}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase block font-sans">Document A</span>
                    <span className="text-red-400 font-bold">{d.dateA}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase block font-sans">Document B</span>
                    <span className="text-emerald-400 font-bold">{d.dateB}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Changed Amounts */}
      {activeTab === 'amounts' && (
        <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8">
          <h3 className="text-base font-bold text-white mb-4">Financial & Consideration Diffs</h3>
          <div className="divide-y divide-slate-800">
            {comparisonResult.differentAmounts?.map((a, i) => (
              <div key={i} className="py-4 first:pt-0 last:pb-0">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-bold text-white text-sm">{a.item}</span>
                  <span className="text-xs font-bold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded-md">
                    {a.difference}
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase block font-sans">Document A</span>
                    <span className="text-slate-300 font-bold">{a.amountA}</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                    <span className="text-[10px] text-slate-500 uppercase block font-sans">Document B</span>
                    <span className="text-emerald-400 font-bold">{a.amountB}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Changed Requirements */}
      {activeTab === 'requirements' && (
        <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8">
          <h3 className="text-base font-bold text-white mb-4">Changed Obligation & Scope Requirements</h3>
          <div className="space-y-4">
            {comparisonResult.changedRequirements?.map((r, i) => (
              <div key={i} className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                <h4 className="text-sm font-bold text-white mb-3">{r.topic}</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300">
                    <span className="text-[10px] text-slate-500 uppercase block font-semibold mb-1">
                      Document A Requirement
                    </span>
                    {r.reqA}
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300">
                    <span className="text-[10px] text-slate-500 uppercase block font-semibold mb-1">
                      Document B Requirement
                    </span>
                    {r.reqB}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
