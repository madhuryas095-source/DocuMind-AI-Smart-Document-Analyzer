import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Star,
  Volume2,
  Filter,
  ShieldAlert,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { ConflictItem, Language } from '../types';
import { getTranslation } from '../utils/i18n';
import { voiceEngine } from '../utils/voice';

interface ConflictsViewProps {
  conflicts: ConflictItem[];
  conflictStatuses: Record<string, 'resolved' | 'ignored' | 'important' | 'unresolved'>;
  onUpdateStatus: (id: string, status: 'resolved' | 'ignored' | 'important' | 'unresolved') => void;
  language: Language;
}

export const ConflictsView: React.FC<ConflictsViewProps> = ({
  conflicts,
  conflictStatuses,
  onUpdateStatus,
  language,
}) => {
  const t = (key: string) => getTranslation(language, key);
  const [filter, setFilter] = useState<'all' | 'unresolved' | 'resolved' | 'important'>('all');
  const [speechPlaying, setSpeechPlaying] = useState(false);

  const getEffectiveStatus = (c: ConflictItem) => conflictStatuses[c.id] || c.status || 'unresolved';

  const filteredConflicts = conflicts.filter((c) => {
    const s = getEffectiveStatus(c);
    if (filter === 'all') return true;
    if (filter === 'unresolved') return s === 'unresolved';
    if (filter === 'resolved') return s === 'resolved';
    if (filter === 'important') return s === 'important';
    return true;
  });

  const resolvedCount = conflicts.filter((c) => getEffectiveStatus(c) === 'resolved').length;
  const unresolvedCount = conflicts.filter((c) => getEffectiveStatus(c) === 'unresolved').length;
  const importantCount = conflicts.filter((c) => getEffectiveStatus(c) === 'important').length;

  const handleSpeakConflicts = () => {
    if (speechPlaying) {
      voiceEngine.stop();
      setSpeechPlaying(false);
    } else {
      const summary = `Detected ${conflicts.length} contradictions. ` +
        conflicts
          .map(
            (c) =>
              `${c.title} in category ${c.category}. Document A says: ${c.docAQuote}. Document B says: ${c.docBQuote}.`
          )
          .join(' Next contradiction: ');
      voiceEngine.speak(
        summary,
        language,
        () => setSpeechPlaying(false),
        () => setSpeechPlaying(false)
      );
      setSpeechPlaying(true);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-red-500/10 border border-red-500/20 text-red-300 mb-2">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Contradiction Detection Engine</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              {t('potentialConflicts')}
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-xl">
              Identifies conflicting commitments, contradictory deadlines, and diverging financial figures between documents.
            </p>
          </div>

          <button
            onClick={handleSpeakConflicts}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors cursor-pointer self-start sm:self-center"
          >
            <Volume2 className="w-4 h-4 text-red-400" />
            <span>{speechPlaying ? 'Stop Voice' : 'Read All Conflicts Aloud'}</span>
          </button>
        </div>

        {/* Progress Bar */}
        <div className="mt-6 pt-5 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-xs">
            <span className="text-slate-300 font-bold">
              Resolution Progress: {resolvedCount} of {conflicts.length} Resolved
            </span>
          </div>
          <div className="w-full sm:w-64 bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
            <div
              className="bg-gradient-to-r from-red-500 via-amber-500 to-emerald-500 h-2.5 rounded-full transition-all duration-300"
              style={{
                width: `${conflicts.length > 0 ? (resolvedCount / conflicts.length) * 100 : 0}%`,
              }}
            />
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setFilter('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            filter === 'all'
              ? 'bg-indigo-600 text-white'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          All ({conflicts.length})
        </button>
        <button
          onClick={() => setFilter('unresolved')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            filter === 'unresolved'
              ? 'bg-red-600 text-white'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          Unresolved ({unresolvedCount})
        </button>
        <button
          onClick={() => setFilter('important')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            filter === 'important'
              ? 'bg-amber-600 text-white'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          Important ({importantCount})
        </button>
        <button
          onClick={() => setFilter('resolved')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            filter === 'resolved'
              ? 'bg-emerald-600 text-white'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          Resolved ({resolvedCount})
        </button>
      </div>

      {/* Conflicts Cards List */}
      <div className="space-y-4">
        {filteredConflicts.map((c) => {
          const currentStatus = getEffectiveStatus(c);
          return (
            <div
              key={c.id}
              className={`p-6 rounded-3xl border transition-all ${
                currentStatus === 'resolved'
                  ? 'bg-slate-950/40 border-slate-800 opacity-70'
                  : currentStatus === 'important'
                  ? 'bg-amber-950/20 border-amber-500/40 shadow-lg'
                  : 'bg-slate-900/80 border-red-500/30'
              }`}
            >
              {/* Card Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                      currentStatus === 'resolved'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-red-500/20 text-red-400'
                    }`}
                  >
                    <AlertTriangle className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white flex items-center gap-2">
                      <span>{c.title}</span>
                      {currentStatus === 'resolved' && (
                        <span className="text-emerald-400 text-xs font-normal">
                          (Resolved ✓)
                        </span>
                      )}
                      {currentStatus === 'important' && (
                        <span className="text-amber-400 text-xs font-normal">
                          (Marked Important ★)
                        </span>
                      )}
                    </h3>
                    <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-400">
                      <span>Category: <strong className="text-slate-200">{c.category}</strong></span>
                      <span>•</span>
                      <span className="uppercase text-[10px] font-bold text-red-400">
                        {c.severity} Severity
                      </span>
                    </div>
                  </div>
                </div>

                {/* Status Badges */}
                <div className="flex items-center gap-1.5 self-start sm:self-auto">
                  <button
                    onClick={() => onUpdateStatus(c.id, 'resolved')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
                      currentStatus === 'resolved'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{t('resolveConflict')}</span>
                  </button>

                  <button
                    onClick={() => onUpdateStatus(c.id, 'important')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
                      currentStatus === 'important'
                        ? 'bg-amber-600 text-white'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    <Star className="w-3.5 h-3.5 text-amber-400" />
                    <span>{t('importantConflict')}</span>
                  </button>

                  <button
                    onClick={() => onUpdateStatus(c.id, 'ignored')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer ${
                      currentStatus === 'ignored'
                        ? 'bg-slate-700 text-white'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    <span>{t('ignoreConflict')}</span>
                  </button>
                </div>
              </div>

              {/* Side by Side Contradiction Quotations */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
                    <span>Document A Clause</span>
                    <span className="text-red-400">Prior Version</span>
                  </div>
                  <blockquote className="text-xs text-red-300 font-mono bg-red-950/20 p-3 rounded-xl border-l-2 border-red-500 leading-relaxed">
                    {c.docAQuote}
                  </blockquote>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
                    <span>Document B Clause</span>
                    <span className="text-amber-400">Revised Version</span>
                  </div>
                  <blockquote className="text-xs text-amber-300 font-mono bg-amber-950/20 p-3 rounded-xl border-l-2 border-amber-500 leading-relaxed">
                    {c.docBQuote}
                  </blockquote>
                </div>
              </div>

              {/* Impact Explanation & Suggested Resolution */}
              <div className="mt-4 pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <span className="text-slate-400 font-bold block mb-0.5">Material Impact:</span>
                  <p className="text-slate-300">{c.explanation}</p>
                </div>
                {c.suggestedAction && (
                  <div className="p-2.5 rounded-xl bg-indigo-950/30 border border-indigo-500/20 text-indigo-300 sm:max-w-xs shrink-0">
                    <span className="font-bold text-[10px] uppercase text-indigo-400 block mb-0.5">
                      Suggested Action:
                    </span>
                    <p className="text-[11px]">{c.suggestedAction}</p>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
