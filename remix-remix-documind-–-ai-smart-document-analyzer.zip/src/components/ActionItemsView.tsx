import React, { useState } from 'react';
import {
  CheckSquare,
  Calendar,
  Clock,
  Plus,
  Filter,
  CheckCircle2,
  AlertCircle,
  Volume2,
} from 'lucide-react';
import { DocumentRecord, Language, ActionItem, DeadlineItem } from '../types';
import { getTranslation } from '../utils/i18n';
import { voiceEngine } from '../utils/voice';

interface ActionItemsViewProps {
  documents: DocumentRecord[];
  onToggleActionItem: (id: string) => void;
  actionCompletedMap: Record<string, boolean>;
  language: Language;
}

export const ActionItemsView: React.FC<ActionItemsViewProps> = ({
  documents,
  onToggleActionItem,
  actionCompletedMap,
  language,
}) => {
  const t = (key: string) => getTranslation(language, key);
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed' | 'high'>('all');
  const [customTask, setCustomTask] = useState('');
  const [customDeadline, setCustomDeadline] = useState('');

  // Collect all action items across documents
  const allActions: ActionItem[] = documents.flatMap((d) => d.analysis?.actionItems || []);
  const allDeadlines: DeadlineItem[] = documents.flatMap((d) => d.analysis?.deadlines || []);

  const filteredActions = allActions.filter((item) => {
    const isCompleted = actionCompletedMap[item.id] ?? item.completed ?? false;
    if (filter === 'pending') return !isCompleted;
    if (filter === 'completed') return isCompleted;
    if (filter === 'high') return item.priority === 'high';
    return true;
  });

  const completedCount = allActions.filter((a) => actionCompletedMap[a.id] ?? a.completed ?? false).length;

  const handleReadTasks = () => {
    const speech = `You have ${allActions.length} action items. ${allActions
      .map((a) => a.task + (a.deadline ? ` due on ${a.deadline}` : ''))
      .join('. ')}`;
    voiceEngine.speak(speech, language);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 mb-2">
              <CheckSquare className="w-3.5 h-3.5" />
              <span>Extracted Checklist & Timelines</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              {t('actionItems')} & Deadlines
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-xl">
              Verified operational obligations and milestone cutoff dates extracted directly from your documents.
            </p>
          </div>

          <button
            onClick={handleReadTasks}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors cursor-pointer self-start sm:self-center"
          >
            <Volume2 className="w-4 h-4 text-emerald-400" />
            <span>Read Tasks Aloud</span>
          </button>
        </div>

        {/* Progress Bar */}
        <div className="mt-6 pt-5 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <span className="text-xs text-slate-300 font-bold">
            Execution Status: {completedCount} of {allActions.length} Completed
          </span>
          <div className="w-full sm:w-64 bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
            <div
              className="bg-gradient-to-r from-emerald-500 to-teal-400 h-2.5 rounded-full transition-all duration-300"
              style={{
                width: `${allActions.length > 0 ? (completedCount / allActions.length) * 100 : 0}%`,
              }}
            />
          </div>
        </div>
      </div>

      {/* Deadlines Timeline Preview Section */}
      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6">
        <div className="flex items-center gap-2 mb-4">
          <Calendar className="w-4 h-4 text-amber-400" />
          <h3 className="text-base font-bold text-white">Upcoming Document Deadlines</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {allDeadlines.slice(0, 4).map((dl) => (
            <div
              key={dl.id}
              className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-500/40 transition-colors"
            >
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">
                  Milestone
                </span>
                <span
                  className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ${
                    dl.urgency === 'critical'
                      ? 'bg-red-500/20 text-red-300'
                      : 'bg-amber-500/20 text-amber-300'
                  }`}
                >
                  {dl.urgency}
                </span>
              </div>
              <h4 className="text-xs font-bold text-white truncate" title={dl.title}>
                {dl.title}
              </h4>
              <p className="mt-2 text-sm font-extrabold text-amber-300 font-mono flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>{dl.date}</span>
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => setFilter('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            filter === 'all'
              ? 'bg-indigo-600 text-white'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          All Tasks ({allActions.length})
        </button>
        <button
          onClick={() => setFilter('pending')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            filter === 'pending'
              ? 'bg-emerald-600 text-white'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          Pending ({allActions.length - completedCount})
        </button>
        <button
          onClick={() => setFilter('high')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            filter === 'high'
              ? 'bg-red-600 text-white'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          High Priority
        </button>
        <button
          onClick={() => setFilter('completed')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
            filter === 'completed'
              ? 'bg-slate-700 text-white'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          Completed ({completedCount})
        </button>
      </div>

      {/* Action Items List */}
      <div className="space-y-3">
        {filteredActions.map((item) => {
          const isDone = actionCompletedMap[item.id] ?? item.completed ?? false;
          return (
            <div
              key={item.id}
              onClick={() => onToggleActionItem(item.id)}
              className={`p-4 rounded-2xl border flex items-start gap-4 transition-all cursor-pointer ${
                isDone
                  ? 'bg-slate-950/40 border-slate-800 text-slate-500 line-through'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700 text-slate-200'
              }`}
            >
              <input
                type="checkbox"
                checked={isDone}
                onChange={() => onToggleActionItem(item.id)}
                className="mt-1 accent-emerald-500 w-4 h-4 cursor-pointer"
              />
              <div className="flex-1">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <p className="text-sm font-semibold">{item.task}</p>
                  <span
                    className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                      item.priority === 'high'
                        ? 'bg-red-500/20 text-red-300'
                        : item.priority === 'medium'
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {item.priority} Priority
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-4 mt-2 text-xs text-slate-400">
                  {item.deadline && (
                    <span className="flex items-center gap-1.5 text-amber-400 font-mono">
                      <Clock className="w-3.5 h-3.5" /> Due: {item.deadline}
                    </span>
                  )}
                  <span>Assignee: <strong className="text-slate-300">{item.assignee}</strong></span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
