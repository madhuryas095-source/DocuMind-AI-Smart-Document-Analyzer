import React, { useState } from 'react';
import {
  Bell,
  Volume2,
  VolumeX,
  AlertTriangle,
  Calendar,
  CheckCircle2,
  ShieldAlert,
  ArrowRight,
  Radio,
  Check,
} from 'lucide-react';
import { SmartAlert, Language, NavView } from '../types';
import { getTranslation } from '../utils/i18n';
import { playChime, requestNotificationPermission, sendBrowserNotification } from '../utils/sound';

interface AlertsViewProps {
  alerts: SmartAlert[];
  onMarkRead: (id: string) => void;
  onNavigate: (view: NavView) => void;
  soundMuted: boolean;
  onToggleSound: () => void;
  language: Language;
}

export const AlertsView: React.FC<AlertsViewProps> = ({
  alerts,
  onMarkRead,
  onNavigate,
  soundMuted,
  onToggleSound,
  language,
}) => {
  const t = (key: string) => getTranslation(language, key);
  const [browserPerm, setBrowserPerm] = useState<string>(
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'default'
  );

  const handleRequestPush = async () => {
    const res = await requestNotificationPermission();
    setBrowserPerm(res);
    if (res === 'granted') {
      sendBrowserNotification('DocuMind Alerts Enabled', {
        body: 'You will receive immediate notifications for critical deadlines and conflicts.',
      });
      playChime('success', soundMuted);
    }
  };

  const handleTestChime = () => {
    playChime('alert', false); // Play sound test even if muted
  };

  return (
    <div className="space-y-6">
      {/* Alerts Center Header */}
      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 mb-2">
              <Bell className="w-3.5 h-3.5" />
              <span>Smart Alert Broadcast</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              {t('alerts')}
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-xl">
              Real-time notifications for milestone dates, detected contradictions, and urgent compliance tasks.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Sound Toggle */}
            <button
              onClick={onToggleSound}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                soundMuted
                  ? 'bg-slate-900 text-slate-400 border-slate-800'
                  : 'bg-indigo-950/40 text-indigo-300 border-indigo-500/30'
              }`}
            >
              {soundMuted ? <VolumeX className="w-4 h-4 text-slate-500" /> : <Volume2 className="w-4 h-4 text-indigo-400" />}
              <span>{soundMuted ? 'Muted' : 'Sound ON'}</span>
            </button>

            {/* Chime Test Button */}
            <button
              onClick={handleTestChime}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors cursor-pointer"
            >
              Test Chime 🔔
            </button>
          </div>
        </div>

        {/* Browser Push Permission Banner */}
        <div className="mt-6 pt-5 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Radio className="w-4 h-4 text-cyan-400 shrink-0" />
            <span className="text-xs text-slate-300">
              Desktop Notifications:{' '}
              <strong className="text-white capitalize">{browserPerm}</strong>
            </span>
          </div>

          {browserPerm !== 'granted' && (
            <button
              onClick={handleRequestPush}
              className="px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <span>Enable Browser Notifications</span>
            </button>
          )}
        </div>
      </div>

      {/* Alerts Cards List */}
      <div className="space-y-3">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            onClick={() => onMarkRead(alert.id)}
            className={`p-5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer ${
              alert.read
                ? 'bg-slate-950/40 border-slate-800 opacity-70'
                : 'bg-slate-900/90 border-cyan-500/30 shadow-md'
            }`}
          >
            <div className="flex items-start gap-3.5">
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                  alert.category === 'deadline'
                    ? 'bg-amber-500/20 text-amber-400'
                    : alert.category === 'conflict'
                    ? 'bg-red-500/20 text-red-400'
                    : alert.category === 'warning'
                    ? 'bg-purple-500/20 text-purple-400'
                    : 'bg-cyan-500/20 text-cyan-400'
                }`}
              >
                {alert.category === 'deadline' && <Calendar className="w-4 h-4" />}
                {alert.category === 'conflict' && <AlertTriangle className="w-4 h-4" />}
                {alert.category === 'warning' && <ShieldAlert className="w-4 h-4" />}
                {alert.category === 'info' && <Bell className="w-4 h-4" />}
                {alert.category === 'task' && <CheckCircle2 className="w-4 h-4" />}
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-bold text-white">{alert.title}</h4>
                  {!alert.read && (
                    <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  )}
                </div>
                <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                  {alert.message}
                </p>
                <span className="text-[10px] text-slate-500 mt-1 block">
                  {alert.timestamp}
                </span>
              </div>
            </div>

            {alert.actionView && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onMarkRead(alert.id);
                  onNavigate(alert.actionView!);
                }}
                className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-cyan-600 text-slate-300 hover:text-white font-semibold text-xs flex items-center gap-1 transition-all cursor-pointer self-start sm:self-center shrink-0"
              >
                <span>View Action</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
