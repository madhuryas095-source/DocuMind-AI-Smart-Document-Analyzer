import React, { useState, useEffect } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  Play,
  Pause,
  Square,
  Sparkles,
  Command,
  FileText,
  AlertTriangle,
  Calendar,
  CheckCircle2,
  Sliders,
} from 'lucide-react';
import { DocumentRecord, ConflictItem, Language, NavView } from '../types';
import { voiceEngine, VoiceEngineState } from '../utils/voice';
import { getTranslation } from '../utils/i18n';

interface VoiceViewProps {
  activeDoc: DocumentRecord | null;
  conflicts: ConflictItem[];
  language: Language;
  onVoiceNavigate: (view: NavView) => void;
  onVoiceCommandRecognized: (command: string) => void;
}

export const VoiceView: React.FC<VoiceViewProps> = ({
  activeDoc,
  conflicts,
  language,
  onVoiceNavigate,
  onVoiceCommandRecognized,
}) => {
  const t = (key: string) => getTranslation(language, key);

  const [engineState, setEngineState] = useState<VoiceEngineState>(voiceEngine.getState());
  const [speechRate, setSpeechRate] = useState(1.0);
  const [lastTranscript, setLastTranscript] = useState<string>('');
  const [speechStatusMessage, setSpeechStatusMessage] = useState<string>('');
  const [testCustomText, setTestCustomText] = useState<string>(
    activeDoc?.analysis?.summary || 'DocuMind voice interaction engine is active and ready.'
  );

  useEffect(() => {
    const unsub = voiceEngine.subscribe((state) => {
      setEngineState(state);
    });
    return () => {
      unsub();
    };
  }, []);

  const handleStartListening = () => {
    setSpeechStatusMessage('Listening... Please speak your command.');
    const success = voiceEngine.startListening(
      language,
      (transcript) => {
        setLastTranscript(transcript);
        setSpeechStatusMessage(`Recognized: "${transcript}"`);
        onVoiceCommandRecognized(transcript);
      },
      (err) => {
        setSpeechStatusMessage('Microphone recognition error or permission denied.');
      }
    );
    if (!success) {
      setSpeechStatusMessage('Speech recognition is not supported in this browser window.');
    }
  };

  const handleStopListening = () => {
    voiceEngine.stopListening();
    setSpeechStatusMessage('Listening stopped.');
  };

  const handlePlayCustomText = () => {
    voiceEngine.setRate(speechRate);
    if (engineState.isSpeaking && !engineState.isPaused) {
      voiceEngine.pause();
    } else if (engineState.isPaused) {
      voiceEngine.resume();
    } else {
      voiceEngine.speak(testCustomText, language);
    }
  };

  const handleStopSpeech = () => {
    voiceEngine.stop();
  };

  const readActiveSummary = () => {
    if (activeDoc?.analysis?.summary) {
      voiceEngine.speak(activeDoc.analysis.summary, language);
    }
  };

  const readDeadlines = () => {
    if (activeDoc?.analysis?.deadlines) {
      const text = activeDoc.analysis.deadlines
        .map((d) => `${d.title} on ${d.date}. ${d.details}`)
        .join(' ');
      voiceEngine.speak(text, language);
    }
  };

  const readActionItems = () => {
    if (activeDoc?.analysis?.actionItems) {
      const text = activeDoc.analysis.actionItems
        .map((a) => `${a.task} priority ${a.priority}`)
        .join('. ');
      voiceEngine.speak(text, language);
    }
  };

  const readConflicts = () => {
    const text = conflicts
      .map((c) => `${c.title}. Document A: ${c.docAQuote}. Document B: ${c.docBQuote}.`)
      .join(' Next contradiction: ');
    voiceEngine.speak(text, language);
  };

  const sampleCommands = [
    { cmd: '“Show important deadlines”', action: 'Navigates to deadlines and action checklist' },
    { cmd: '“Read summary”', action: 'Narrates the active document AI summary' },
    { cmd: '“Check conflicts”', action: 'Opens the contradiction resolution center' },
    { cmd: '“Compare documents”', action: 'Opens the side-by-side comparison studio' },
    { cmd: '“Switch to offline mode”', action: 'Toggles to on-device offline engine' },
    { cmd: '“Turn on privacy mode”', action: 'Enables maximum privacy restrictions' },
  ];

  return (
    <div className="space-y-6">
      {/* Voice Hub Header */}
      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-violet-500/10 border border-violet-500/20 text-violet-300 mb-2">
              <Volume2 className="w-3.5 h-3.5" />
              <span>Web Speech API Engine</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              Voice Assistant & Audio Narration
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-xl">
              Hands-free document exploration with natural voice commands and multilingual text-to-speech narration.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: Speech Recognition (Voice Commands) */}
        <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8 space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center">
              <Mic className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Speech Recognition</h3>
              <p className="text-xs text-slate-400">Speak voice commands to navigate & query</p>
            </div>
          </div>

          {/* Big Mic Button & Visualizer */}
          <div className="p-8 rounded-2xl bg-slate-950 border border-slate-800/80 text-center flex flex-col items-center justify-center relative overflow-hidden">
            {engineState.isListening && (
              <div className="absolute inset-0 bg-red-500/5 animate-pulse pointer-events-none" />
            )}

            <button
              onClick={engineState.isListening ? handleStopListening : handleStartListening}
              className={`w-20 h-20 rounded-3xl flex items-center justify-center transition-all cursor-pointer shadow-xl ${
                engineState.isListening
                  ? 'bg-red-600 text-white animate-pulse ring-8 ring-red-500/20 shadow-red-600/30'
                  : 'bg-gradient-to-tr from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white shadow-indigo-600/30 hover:scale-105'
              }`}
            >
              {engineState.isListening ? <MicOff className="w-8 h-8" /> : <Mic className="w-8 h-8" />}
            </button>

            <span className="mt-4 text-xs font-bold text-slate-200">
              {engineState.isListening ? 'Listening for speech...' : 'Click to Speak'}
            </span>
            <p className="text-[11px] text-slate-400 mt-1 max-w-xs">
              {speechStatusMessage || 'Press the microphone and say “Show important deadlines”'}
            </p>

            {lastTranscript && (
              <div className="mt-4 p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-indigo-300 font-mono w-full text-center">
                “{lastTranscript}”
              </div>
            )}
          </div>

          {/* Recognized Command Shortcuts */}
          <div>
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
              Supported Voice Commands
            </h4>
            <div className="space-y-2">
              {sampleCommands.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => onVoiceCommandRecognized(item.cmd.replace(/[“”]/g, ''))}
                  className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-indigo-500/40 text-xs flex items-center justify-between transition-colors cursor-pointer"
                >
                  <span className="font-mono text-indigo-300 font-bold">{item.cmd}</span>
                  <span className="text-[11px] text-slate-400">{item.action}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Text-to-Speech (Audio Reader) */}
        <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8 space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center">
              <Volume2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Text-to-Speech Narration</h3>
              <p className="text-xs text-slate-400">Synthesize document insights with speed control</p>
            </div>
          </div>

          {/* Quick Narration Trigger Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={readActiveSummary}
              className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-purple-500/50 text-left transition-colors cursor-pointer group"
            >
              <FileText className="w-4 h-4 text-purple-400 mb-1 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold text-white block">Read AI Summary</span>
              <span className="text-[10px] text-slate-400">Executive digest</span>
            </button>

            <button
              onClick={readDeadlines}
              className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-500/50 text-left transition-colors cursor-pointer group"
            >
              <Calendar className="w-4 h-4 text-amber-400 mb-1 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold text-white block">Read Deadlines</span>
              <span className="text-[10px] text-slate-400">Milestone dates</span>
            </button>

            <button
              onClick={readActionItems}
              className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-500/50 text-left transition-colors cursor-pointer group"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400 mb-1 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold text-white block">Read Action Items</span>
              <span className="text-[10px] text-slate-400">Assigned deliverables</span>
            </button>

            <button
              onClick={readConflicts}
              className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 hover:border-red-500/50 text-left transition-colors cursor-pointer group"
            >
              <AlertTriangle className="w-4 h-4 text-red-400 mb-1 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold text-white block">Read Conflicts</span>
              <span className="text-[10px] text-slate-400">Contradictions list</span>
            </button>
          </div>

          {/* Interactive Narration Sandbox */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300">Custom Narration Reader</span>
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-400">Rate: {speechRate}x</span>
                <input
                  type="range"
                  min="0.5"
                  max="1.75"
                  step="0.25"
                  value={speechRate}
                  onChange={(e) => {
                    const r = parseFloat(e.target.value);
                    setSpeechRate(r);
                    voiceEngine.setRate(r);
                  }}
                  className="w-20 accent-purple-500 cursor-pointer"
                />
              </div>
            </div>

            <textarea
              value={testCustomText}
              onChange={(e) => setTestCustomText(e.target.value)}
              rows={3}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 resize-none outline-none focus:border-purple-500"
              placeholder="Type any sentence to read aloud..."
            />

            <div className="flex items-center gap-3">
              <button
                onClick={handlePlayCustomText}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md shadow-purple-600/30"
              >
                {engineState.isSpeaking && !engineState.isPaused ? (
                  <>
                    <Pause className="w-3.5 h-3.5" />
                    <span>Pause</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" />
                    <span>{engineState.isPaused ? 'Resume' : 'Speak'}</span>
                  </>
                )}
              </button>

              {engineState.isSpeaking && (
                <button
                  onClick={handleStopSpeech}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Square className="w-3.5 h-3.5" />
                  <span>Stop</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
