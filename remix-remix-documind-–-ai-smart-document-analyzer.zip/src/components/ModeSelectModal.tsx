import React from 'react';
import { motion } from 'motion/react';
import { Shield, Zap, Check, Lock, Sparkles, ArrowRight, X } from 'lucide-react';
import { AppMode, Language } from '../types';
import { getTranslation } from '../utils/i18n';

interface ModeSelectModalProps {
  currentMode: AppMode;
  currentLanguage: Language;
  onSelectMode: (mode: AppMode) => void;
  onClose?: () => void;
  isModal?: boolean;
}

export const ModeSelectModal: React.FC<ModeSelectModalProps> = ({
  currentMode,
  currentLanguage,
  onSelectMode,
  onClose,
  isModal = false,
}) => {
  const t = (key: string) => getTranslation(currentLanguage, key);

  const containerClasses = isModal
    ? 'fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto'
    : 'min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-6 relative overflow-hidden';

  return (
    <div className={containerClasses}>
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl relative"
      >
        {isModal && onClose && (
          <button
            onClick={onClose}
            className="absolute top-6 right-6 p-2 rounded-full bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        <div className="text-center max-w-xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Architecture Choice</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight">
            {t('modeSelectionTitle')}
          </h2>
          <p className="mt-3 text-sm text-slate-400 leading-relaxed">
            {t('modeSelectionSubtitle')}
          </p>
        </div>

        {/* The Two Large Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Card 1: Offline Mode */}
          <div
            onClick={() => onSelectMode('offline')}
            className={`relative rounded-2xl p-7 border-2 transition-all cursor-pointer flex flex-col justify-between group ${
              currentMode === 'offline'
                ? 'bg-emerald-950/30 border-emerald-500 shadow-xl shadow-emerald-950/50'
                : 'bg-slate-950/60 border-slate-800 hover:border-emerald-500/50 hover:bg-slate-950'
            }`}
          >
            {currentMode === 'offline' && (
              <span className="absolute top-5 right-5 inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
                <Check className="w-3.5 h-3.5" /> Active
              </span>
            )}

            <div>
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mb-5">
                <Lock className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                {t('offlineModeTitle')}
              </h3>
              <p className="mt-2 text-xs text-slate-400 leading-relaxed">
                {t('offlineModeDesc')}
              </p>

              <div className="mt-6 space-y-3 pt-5 border-t border-slate-800/80">
                <div className="flex items-start gap-2.5 text-xs text-slate-300">
                  <div className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mt-0.5 shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>{t('offlineFeature1')}</span>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-slate-300">
                  <div className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mt-0.5 shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>{t('offlineFeature2')}</span>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-slate-300">
                  <div className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mt-0.5 shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>{t('offlineFeature3')}</span>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-slate-300">
                  <div className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mt-0.5 shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>{t('offlineFeature4')}</span>
                </div>
              </div>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                onSelectMode('offline');
              }}
              className={`mt-8 w-full py-3 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                currentMode === 'offline'
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
              }`}
            >
              <span>{currentMode === 'offline' ? 'Continue with Offline Mode' : 'Select Offline Mode'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Card 2: Online Mode */}
          <div
            onClick={() => onSelectMode('online')}
            className={`relative rounded-2xl p-7 border-2 transition-all cursor-pointer flex flex-col justify-between group ${
              currentMode === 'online'
                ? 'bg-blue-950/30 border-blue-500 shadow-xl shadow-blue-950/50'
                : 'bg-slate-950/60 border-slate-800 hover:border-blue-500/50 hover:bg-slate-950'
            }`}
          >
            {currentMode === 'online' && (
              <span className="absolute top-5 right-5 inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-blue-500/20 text-blue-300 text-xs font-bold border border-blue-500/30">
                <Check className="w-3.5 h-3.5" /> Active
              </span>
            )}

            <div>
              <div className="w-14 h-14 rounded-2xl bg-blue-500/15 border border-blue-500/30 text-blue-400 flex items-center justify-center mb-5">
                <Zap className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                {t('onlineModeTitle')}
              </h3>
              <p className="mt-2 text-xs text-slate-400 leading-relaxed">
                {t('onlineModeDesc')}
              </p>

              <div className="mt-6 space-y-3 pt-5 border-t border-slate-800/80">
                <div className="flex items-start gap-2.5 text-xs text-slate-300">
                  <div className="w-4 h-4 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center mt-0.5 shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>{t('onlineFeature1')}</span>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-slate-300">
                  <div className="w-4 h-4 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center mt-0.5 shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>{t('onlineFeature2')}</span>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-slate-300">
                  <div className="w-4 h-4 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center mt-0.5 shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>{t('onlineFeature3')}</span>
                </div>
                <div className="flex items-start gap-2.5 text-xs text-slate-300">
                  <div className="w-4 h-4 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center mt-0.5 shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span>{t('onlineFeature4')}</span>
                </div>
              </div>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                onSelectMode('online');
              }}
              className={`mt-8 w-full py-3 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                currentMode === 'online'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-lg shadow-blue-600/30'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
              }`}
            >
              <span>{currentMode === 'online' ? 'Continue with Online Mode' : 'Select Online Mode'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <p className="mt-8 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
          <Shield className="w-3.5 h-3.5 text-slate-400" />
          <span>{t('switchModeAnytime')}</span>
        </p>
      </motion.div>
    </div>
  );
};
