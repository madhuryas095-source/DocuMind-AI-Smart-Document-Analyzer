import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Lock,
  Trash2,
  HardDrive,
  CheckCircle2,
  AlertCircle,
  Cpu,
  Globe,
  RefreshCw,
} from 'lucide-react';
import { AppMode, Language } from '../types';
import { getTranslation } from '../utils/i18n';
import { StorageService } from '../utils/storage';

interface PrivacyViewProps {
  privacyMode: boolean;
  onTogglePrivacy: () => void;
  activeMode: AppMode;
  onClearAllData: () => void;
  language: Language;
}

export const PrivacyView: React.FC<PrivacyViewProps> = ({
  privacyMode,
  onTogglePrivacy,
  activeMode,
  onClearAllData,
  language,
}) => {
  const t = (key: string) => getTranslation(language, key);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [clearedNotice, setClearedNotice] = useState(false);
  const footprint = StorageService.getStorageFootprint();

  const handleClear = () => {
    onClearAllData();
    setShowConfirmModal(false);
    setClearedNotice(true);
    setTimeout(() => setClearedNotice(false), 3500);
  };

  return (
    <div className="space-y-6">
      {/* Privacy Mode Big Banner */}
      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div
              className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 border ${
                privacyMode
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                  : 'bg-slate-800 border-slate-700 text-slate-400'
              }`}
            >
              {privacyMode ? <Lock className="w-7 h-7" /> : <ShieldAlert className="w-7 h-7" />}
            </div>

            <div>
              <div className="flex items-center gap-2 mb-1">
                <span
                  className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 border ${
                    privacyMode
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  <Lock className="w-3 h-3" />
                  <span>{privacyMode ? '🔒 Privacy Mode ON' : 'Privacy Mode OFF'}</span>
                </span>
                <span className="text-xs text-slate-400">
                  Engine: <strong className="text-white capitalize">{activeMode}</strong>
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
                Data Privacy & Compliance Governance
              </h2>
              <p className="text-xs text-slate-400 mt-1 max-w-xl">
                In Privacy Mode, document text remains locked inside your browser. No unnecessary cloud uploads or telemetry logs.
              </p>
            </div>
          </div>

          <button
            onClick={onTogglePrivacy}
            className={`px-6 py-3 rounded-2xl font-bold text-xs transition-all cursor-pointer shadow-lg self-start sm:self-center ${
              privacyMode
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
            }`}
          >
            {privacyMode ? 'Privacy Mode is Active' : 'Activate Privacy Mode'}
          </button>
        </div>
      </div>

      {clearedNotice && (
        <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{t('dataCleared')}</span>
        </div>
      )}

      {/* Privacy Guarantees & Safeguards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase mb-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>Local Device Processing</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            In Offline Mode, all text extraction, entity matching, and conflict comparison runs 100% locally via deterministic heuristics.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center gap-2 text-blue-400 font-bold text-xs uppercase mb-2">
            <Globe className="w-4 h-4" />
            <span>Transparent Cloud Boundary</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            When Online Mode is engaged, document text is sent via secure server proxy to Gemini 3.8 Flash solely for analysis and is never retained.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center gap-2 text-purple-400 font-bold text-xs uppercase mb-2">
            <HardDrive className="w-4 h-4" />
            <span>Zero Third-Party Telemetry</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            DocuMind contains zero external advertising trackers or analytics cookies. Your files remain exclusively yours.
          </p>
        </div>
      </div>

      {/* Local Storage Vault & Clear Data */}
      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white">Browser Storage Vault</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Current local storage usage on this machine:
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-3.5 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300">
              Storage Footprint:{' '}
              <strong className="text-indigo-400">{footprint.estimatedKb} KB</strong> (
              {footprint.count} cached records)
            </div>

            <button
              onClick={() => setShowConfirmModal(true)}
              className="px-4 py-2 rounded-xl bg-red-600/20 hover:bg-red-600 border border-red-500/30 hover:border-red-600 text-red-300 hover:text-white font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{t('clearLocalData')}</span>
            </button>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 text-xs text-slate-400 space-y-2">
          <p className="font-semibold text-slate-200">Data Stored Locally:</p>
          <ul className="list-disc list-inside space-y-1 text-slate-300 text-[11px]">
            <li>Uploaded document text files & parsed previews</li>
            <li>Resolved and ignored conflict status tags</li>
            <li>Completed action items and checklists</li>
            <li>User interface language and audio settings</li>
          </ul>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 flex items-center justify-center mb-4">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">Purge All Local Records?</h3>
            <p className="text-xs text-slate-300 mb-6 leading-relaxed">
              {t('clearDataConfirm')}
            </p>
            <div className="flex items-center justify-end gap-3">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleClear}
                className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold shadow-md shadow-red-600/30 transition-all cursor-pointer"
              >
                Yes, Permanently Purge All Data
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
