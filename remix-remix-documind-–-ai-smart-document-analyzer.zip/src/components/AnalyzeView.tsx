import React, { useState } from 'react';
import {
  FileText,
  Sparkles,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Square,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  Clock,
  Layers,
  HelpCircle,
  TrendingUp,
  MapPin,
  DollarSign,
  Tag,
  User,
  ShieldAlert,
  RefreshCw,
  Zap,
  Lock,
} from 'lucide-react';
import { DocumentRecord, AppMode, Language, AnalysisResult } from '../types';
import { getTranslation } from '../utils/i18n';
import { voiceEngine } from '../utils/voice';

interface AnalyzeViewProps {
  document: DocumentRecord | null;
  documents: DocumentRecord[];
  onSelectDoc: (id: string) => void;
  activeMode: AppMode;
  language: Language;
  onReanalyzeWithGemini: (docId: string) => void;
  isAnalyzing: boolean;
  onToggleActionItem: (id: string) => void;
  actionCompletedMap: Record<string, boolean>;
}

export const AnalyzeView: React.FC<AnalyzeViewProps> = ({
  document,
  documents,
  onSelectDoc,
  activeMode,
  language,
  onReanalyzeWithGemini,
  isAnalyzing,
  onToggleActionItem,
  actionCompletedMap,
}) => {
  const t = (key: string) => getTranslation(language, key);

  const [activeTab, setActiveTab] = useState<'overview' | 'summary' | 'important' | 'actions' | 'deadlines' | 'clarity'>('overview');
  const [speechPlaying, setSpeechPlaying] = useState(false);
  const [speechRate, setSpeechRate] = useState(1.0);

  if (!document) {
    return (
      <div className="rounded-3xl bg-slate-900/60 border border-slate-800 p-12 text-center max-w-lg mx-auto">
        <FileText className="w-12 h-12 text-slate-500 mx-auto mb-4" />
        <h3 className="text-lg font-bold text-white mb-2">{t('noDocSelected')}</h3>
        <p className="text-xs text-slate-400 mb-6">
          Please select a document from the vault or upload a new file.
        </p>
        {documents.length > 0 && (
          <div className="flex flex-wrap items-center justify-center gap-2">
            {documents.slice(0, 3).map((d) => (
              <button
                key={d.id}
                onClick={() => onSelectDoc(d.id)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 transition-colors cursor-pointer"
              >
                {d.title}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  const analysis: AnalysisResult = document.analysis || {
    summary: 'Document ready for analysis.',
    documentType: 'Standard Document',
    wordCount: document.content.split(/\s+/).filter(Boolean).length,
    clarityScore: 80,
    clarityBreakdown: {
      readability: 80,
      missingInfo: 80,
      ambiguousStatements: 80,
      complexSentences: 80,
      contradictions: 90,
      keyInfoVisibility: 85,
    },
    clarityRecommendations: ['Review document structure for clarity.'],
    importantInformation: {
      facts: [],
      names: [],
      dates: [],
      amounts: [],
      locations: [],
      requirements: [],
    },
    actionItems: [],
    deadlines: [],
    potentialRisks: [],
  };

  const handleSpeakText = (text: string) => {
    voiceEngine.setRate(speechRate);
    if (speechPlaying) {
      voiceEngine.stop();
      setSpeechPlaying(false);
    } else {
      voiceEngine.speak(
        text,
        language,
        () => setSpeechPlaying(false),
        () => setSpeechPlaying(false)
      );
      setSpeechPlaying(true);
    }
  };

  const stopVoice = () => {
    voiceEngine.stop();
    setSpeechPlaying(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Document Header Bar & Switcher */}
      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              {analysis.documentType}
            </span>
            <span
              className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 border ${
                analysis.source === 'gemini-3.8-flash'
                  ? 'bg-blue-500/10 text-blue-400 border-blue-500/30'
                  : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
              }`}
            >
              {analysis.source === 'gemini-3.8-flash' ? <Zap className="w-2.5 h-2.5" /> : <Lock className="w-2.5 h-2.5" />}
              {analysis.source === 'gemini-3.8-flash' ? 'Gemini 3.8 Flash' : 'On-Device Engine'}
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
            {document.title}
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            File: {document.fileName} • {(document.fileSize / 1024).toFixed(1)} KB •{' '}
            {analysis.wordCount} words
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Document switcher dropdown */}
          <select
            value={document.id}
            onChange={(e) => onSelectDoc(e.target.value)}
            aria-label="Select document to analyze"
            className="bg-slate-950 border border-slate-800 text-xs text-slate-300 rounded-xl px-3 py-2 outline-none cursor-pointer"
          >
            {documents.map((d) => (
              <option key={d.id} value={d.id}>
                {d.title}
              </option>
            ))}
          </select>

          {/* Re-analyze with Gemini button (if online) */}
          <button
            onClick={() => onReanalyzeWithGemini(document.id)}
            disabled={isAnalyzing}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all shadow-md cursor-pointer disabled:opacity-50"
            title="Re-run deep analysis"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isAnalyzing ? 'animate-spin' : ''}`} />
            <span>{isAnalyzing ? 'Analyzing...' : 'Deep AI Re-Analyze'}</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 overflow-x-auto no-scrollbar">
        {[
          { id: 'overview', label: 'Document Overview' },
          { id: 'summary', label: 'AI Summary' },
          { id: 'important', label: 'Important Information' },
          { id: 'actions', label: `Action Items (${analysis.actionItems?.length || 0})` },
          { id: 'deadlines', label: `Deadlines (${analysis.deadlines?.length || 0})` },
          { id: 'clarity', label: `Clarity Score (${analysis.clarityScore}/100)` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab 1: Overview */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-400">Doc Title</span>
              <p className="text-xs font-bold text-white mt-1 truncate" title={document.title}>
                {document.title}
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-400">Document Type</span>
              <p className="text-xs font-bold text-indigo-400 mt-1 truncate">
                {analysis.documentType}
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-400">Word Count</span>
              <p className="text-base font-extrabold text-white mt-0.5">
                {analysis.wordCount} words
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-400">Estimated Pages</span>
              <p className="text-base font-extrabold text-white mt-0.5">
                {Math.max(1, Math.ceil(analysis.wordCount / 350))} Pages
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-400">Language</span>
              <p className="text-xs font-bold text-white mt-1 capitalize">{language}</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
              <span className="text-[10px] uppercase font-bold text-slate-400">Clarity Score</span>
              <p className="text-base font-extrabold text-emerald-400 mt-0.5">
                {analysis.clarityScore}/100
              </p>
            </div>
          </div>

          {/* AI Summary Highlight Box */}
          <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                <h3 className="text-sm font-bold text-white">Executive Synthesis</h3>
              </div>
              <button
                onClick={() => handleSpeakText(analysis.summary)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors cursor-pointer"
              >
                <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
                <span>{speechPlaying ? 'Stop Voice' : 'Read Aloud'}</span>
              </button>
            </div>
            <p className="text-sm text-slate-300 leading-relaxed font-sans">{analysis.summary}</p>
          </div>

          {/* Document Raw Text Preview */}
          <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6">
            <h3 className="text-sm font-bold text-white mb-3">Sanitized Extracted Text</h3>
            <pre className="p-4 rounded-2xl bg-slate-950 border border-slate-800/80 text-xs text-slate-300 font-mono whitespace-pre-wrap max-h-80 overflow-y-auto leading-relaxed">
              {document.content}
            </pre>
          </div>
        </div>
      )}

      {/* Tab 2: AI Summary */}
      {activeTab === 'summary' && (
        <div className="space-y-6">
          <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">AI Document Summary</h3>
                  <p className="text-xs text-slate-400">Concise, actionable executive digest</p>
                </div>
              </div>

              {/* TTS Controls */}
              <div className="flex items-center gap-3 bg-slate-950 p-2 rounded-2xl border border-slate-800">
                <button
                  onClick={() => handleSpeakText(analysis.summary)}
                  className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  {speechPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{speechPlaying ? 'Pause' : 'Listen'}</span>
                </button>
                {speechPlaying && (
                  <button
                    onClick={stopVoice}
                    className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                  >
                    <Square className="w-3.5 h-3.5" />
                  </button>
                )}
                <div className="flex items-center gap-1 text-[11px] text-slate-400 pl-2 border-l border-slate-800">
                  <span>Speed:</span>
                  <select
                    value={speechRate}
                    onChange={(e) => {
                      const r = parseFloat(e.target.value);
                      setSpeechRate(r);
                      voiceEngine.setRate(r);
                    }}
                    aria-label="Speech playback rate"
                    className="bg-transparent text-slate-200 outline-none cursor-pointer"
                  >
                    <option value="0.75" className="bg-slate-900">0.75x</option>
                    <option value="1.0" className="bg-slate-900">1.0x</option>
                    <option value="1.25" className="bg-slate-900">1.25x</option>
                    <option value="1.5" className="bg-slate-900">1.5x</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="p-6 rounded-2xl bg-indigo-950/20 border border-indigo-500/20 text-slate-200 text-base leading-relaxed">
              {analysis.summary}
            </div>

            {/* Potential Risks flag */}
            {analysis.potentialRisks && analysis.potentialRisks.length > 0 && (
              <div className="mt-6 p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 text-amber-200 text-xs">
                <div className="flex items-center gap-2 font-bold mb-2 text-amber-400">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Noteworthy Risks & Ambiguities Flagged:</span>
                </div>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  {analysis.potentialRisks.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Important Information */}
      {activeTab === 'important' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Important Facts */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center gap-2 text-indigo-400 font-bold text-xs uppercase mb-3">
              <Sparkles className="w-4 h-4" />
              <span>Key Facts & Stipulations</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-300">
              {analysis.importantInformation.facts?.map((f, i) => (
                <li key={i} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                  {f}
                </li>
              ))}
            </ul>
          </div>

          {/* Names & Entities */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center gap-2 text-blue-400 font-bold text-xs uppercase mb-3">
              <User className="w-4 h-4" />
              <span>Parties & Names</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-300">
              {analysis.importantInformation.names?.map((n, i) => (
                <li key={i} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center justify-between">
                  <span>{n}</span>
                  <Tag className="w-3 h-3 text-slate-500" />
                </li>
              ))}
            </ul>
          </div>

          {/* Key Dates */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase mb-3">
              <Calendar className="w-4 h-4" />
              <span>Extracted Dates</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-300">
              {analysis.importantInformation.dates?.map((d, i) => (
                <li key={i} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 flex items-center gap-2 font-mono text-amber-300">
                  <Clock className="w-3 h-3 text-amber-500" />
                  <span>{d}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Amounts */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase mb-3">
              <DollarSign className="w-4 h-4" />
              <span>Financials & Amounts</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-300">
              {analysis.importantInformation.amounts?.map((a, i) => (
                <li key={i} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80 font-mono text-emerald-300">
                  {a}
                </li>
              ))}
            </ul>
          </div>

          {/* Locations */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center gap-2 text-purple-400 font-bold text-xs uppercase mb-3">
              <MapPin className="w-4 h-4" />
              <span>Locations & Venues</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-300">
              {analysis.importantInformation.locations?.map((l, i) => (
                <li key={i} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                  {l}
                </li>
              ))}
            </ul>
          </div>

          {/* Requirements */}
          <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center gap-2 text-rose-400 font-bold text-xs uppercase mb-3">
              <ShieldAlert className="w-4 h-4" />
              <span>Prerequisites & Requirements</span>
            </div>
            <ul className="space-y-2 text-xs text-slate-300">
              {analysis.importantInformation.requirements?.map((r, i) => (
                <li key={i} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/80">
                  {r}
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Tab 4: Action Items */}
      {activeTab === 'actions' && (
        <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-bold text-white">Action Items & Deliverables</h3>
              <p className="text-xs text-slate-400">
                Tasks identified from document obligations. Check off tasks as completed.
              </p>
            </div>
            <button
              onClick={() => {
                const textToRead = analysis.actionItems
                  .map((a) => a.task + (a.deadline ? ` due by ${a.deadline}` : ''))
                  .join('. ');
                handleSpeakText(textToRead);
              }}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
              <span>Read Action Items</span>
            </button>
          </div>

          <div className="space-y-3">
            {analysis.actionItems?.map((item) => {
              const isDone = actionCompletedMap[item.id] ?? item.completed ?? false;
              return (
                <div
                  key={item.id}
                  onClick={() => onToggleActionItem(item.id)}
                  className={`p-4 rounded-2xl border flex items-start gap-3.5 transition-all cursor-pointer ${
                    isDone
                      ? 'bg-slate-950/40 border-slate-800 opacity-60 line-through'
                      : 'bg-slate-950 border-slate-800/90 hover:border-slate-700 text-slate-200'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={isDone}
                    onChange={() => onToggleActionItem(item.id)}
                    className="mt-1 accent-emerald-500 w-4 h-4 cursor-pointer"
                  />
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <p className="text-sm font-semibold">{item.task}</p>
                      <span
                        className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                          item.priority === 'high'
                            ? 'bg-red-500/20 text-red-300'
                            : item.priority === 'medium'
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {item.priority} Priority
                      </span>
                    </div>

                    <div className="flex items-center gap-4 mt-2 text-xs text-slate-400">
                      {item.deadline && (
                        <span className="flex items-center gap-1 text-amber-400">
                          <Calendar className="w-3 h-3" /> Due: {item.deadline}
                        </span>
                      )}
                      <span>Assignee: {item.assignee}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 5: Deadlines */}
      {activeTab === 'deadlines' && (
        <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-bold text-white">Detected Milestone Deadlines</h3>
              <p className="text-xs text-slate-400">
                Crucial cutoff dates requiring active calendar compliance.
              </p>
            </div>
            <button
              onClick={() => {
                const textToRead = analysis.deadlines
                  .map((d) => `${d.title} on ${d.date}`)
                  .join('. ');
                handleSpeakText(textToRead);
              }}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Volume2 className="w-3.5 h-3.5 text-indigo-400" />
              <span>Read Deadlines</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {analysis.deadlines?.map((dl) => (
              <div
                key={dl.id}
                className="p-5 rounded-2xl bg-slate-950 border border-slate-800 relative overflow-hidden"
              >
                <div
                  className={`absolute top-0 left-0 bottom-0 w-1.5 ${
                    dl.urgency === 'critical'
                      ? 'bg-red-500'
                      : dl.urgency === 'warning'
                      ? 'bg-amber-500'
                      : 'bg-blue-500'
                  }`}
                />
                <div className="pl-2">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-bold text-white text-sm">{dl.title}</span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                        dl.urgency === 'critical'
                          ? 'bg-red-500/20 text-red-300'
                          : dl.urgency === 'warning'
                          ? 'bg-amber-500/20 text-amber-300'
                          : 'bg-blue-500/20 text-blue-300'
                      }`}
                    >
                      {dl.urgency}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 mt-2 text-base font-extrabold text-amber-300 font-mono">
                    <Calendar className="w-4 h-4 text-amber-400" />
                    <span>{dl.date}</span>
                  </div>

                  <p className="mt-2 text-xs text-slate-400">{dl.details}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 6: Document Clarity Score & Recommendations */}
      {activeTab === 'clarity' && (
        <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6 sm:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 pb-6 border-b border-slate-800">
            <div>
              <h3 className="text-lg font-bold text-white">Document Clarity Index</h3>
              <p className="text-xs text-slate-400">
                Comprehensive linguistic assessment across readability, ambiguity, and risk factors.
              </p>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right">
                <span className="text-3xl font-extrabold text-white">
                  {analysis.clarityScore}
                  <span className="text-base text-slate-500">/100</span>
                </span>
                <p className="text-[11px] text-emerald-400 font-bold">
                  {analysis.clarityScore >= 80
                    ? 'Excellent Clarity'
                    : analysis.clarityScore >= 65
                    ? 'Moderate Clarity'
                    : 'Requires Clarification'}
                </p>
              </div>
            </div>
          </div>

          {/* Breakdown Meters */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { label: 'Readability', val: analysis.clarityBreakdown?.readability || 85 },
              { label: 'Completeness (Missing Info)', val: analysis.clarityBreakdown?.missingInfo || 80 },
              { label: 'Precision (Ambiguity Free)', val: analysis.clarityBreakdown?.ambiguousStatements || 75 },
              { label: 'Sentence Simplicity', val: analysis.clarityBreakdown?.complexSentences || 82 },
              { label: 'Internal Consistency', val: analysis.clarityBreakdown?.contradictions || 90 },
              { label: 'Key Info Visibility', val: analysis.clarityBreakdown?.keyInfoVisibility || 88 },
            ].map((metric) => (
              <div key={metric.label} className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-300 mb-2">
                  <span>{metric.label}</span>
                  <span className="text-indigo-400 font-bold">{metric.val}%</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                  <div
                    className={`h-2 rounded-full ${
                      metric.val >= 80
                        ? 'bg-emerald-500'
                        : metric.val >= 65
                        ? 'bg-amber-500'
                        : 'bg-red-500'
                    }`}
                    style={{ width: `${metric.val}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Actionable Recommendations */}
          <div className="p-6 rounded-2xl bg-indigo-950/20 border border-indigo-500/30">
            <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-400" />
              <span>Recommendations to Maximize Clarity & Remove Ambiguity:</span>
            </h4>
            <div className="space-y-2.5">
              {analysis.clarityRecommendations?.map((rec, i) => (
                <div key={i} className="flex items-start gap-2.5 text-xs text-slate-300">
                  <div className="w-4 h-4 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 mt-0.5">
                    {i + 1}
                  </div>
                  <span>{rec}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
