import React, { useState, useRef } from 'react';
import {
  Upload,
  FileText,
  Trash2,
  Search,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
  Image as ImageIcon,
  Lock,
  Zap,
} from 'lucide-react';
import { DocumentRecord, AppMode, Language } from '../types';
import { getTranslation } from '../utils/i18n';
import { extractTextFromFile, analyzeDocumentOffline } from '../utils/fileExtractor';

interface DocumentUploadViewProps {
  documents: DocumentRecord[];
  activeMode: AppMode;
  language: Language;
  onAddDocument: (doc: DocumentRecord) => void;
  onDeleteDocument: (id: string) => void;
  onAnalyzeDocument: (id: string) => void;
  onLoadDemoContracts: () => void;
  onLoadDemoAdmissions: () => void;
  onLoadDemoPolicy: () => void;
}

export const DocumentUploadView: React.FC<DocumentUploadViewProps> = ({
  documents,
  activeMode,
  language,
  onAddDocument,
  onDeleteDocument,
  onAnalyzeDocument,
  onLoadDemoContracts,
  onLoadDemoAdmissions,
  onLoadDemoPolicy,
}) => {
  const t = (key: string) => getTranslation(language, key);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [currentFileName, setCurrentFileName] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileProcess = async (file: File) => {
    try {
      setErrorMessage(null);
      setIsProcessing(true);
      setCurrentFileName(file.name);
      setUploadProgress(15);

      // Simulate step-by-step progress
      const p1 = setTimeout(() => setUploadProgress(45), 200);
      const p2 = setTimeout(() => setUploadProgress(75), 450);

      // Extract text safely using on-device extraction
      const { text, pageCount } = await extractTextFromFile(file);

      clearTimeout(p1);
      clearTimeout(p2);
      setUploadProgress(90);

      // Generate initial analysis locally (or will be re-analyzed via Gemini online)
      const initialAnalysis = analyzeDocumentOffline(text, file.name.replace(/\.[^/.]+$/, ''));

      setUploadProgress(100);

      const newDoc: DocumentRecord = {
        id: `doc-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        title: file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '),
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type || 'text/plain',
        uploadedAt: new Date().toISOString(),
        content: text,
        analysis: initialAnalysis,
      };

      setTimeout(() => {
        onAddDocument(newDoc);
        setIsProcessing(false);
        setUploadProgress(null);
        setCurrentFileName(null);
      }, 300);
    } catch (err: any) {
      setIsProcessing(false);
      setUploadProgress(null);
      setErrorMessage(err.message || 'Failed to process document');
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileProcess(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFileProcess(e.target.files[0]);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-extrabold text-white tracking-tight">{t('uploadDocument')}</h2>
        <p className="mt-1 text-sm text-slate-400">
          Upload PDF, DOCX, TXT, or scan images. Files are processed securely according to your current{' '}
          <strong className="text-slate-200">{activeMode === 'offline' ? 'Offline' : 'Online'}</strong> mode settings.
        </p>
      </div>

      {/* Drag & Drop Zone */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-3xl p-8 sm:p-12 text-center transition-all cursor-pointer ${
          isDragging
            ? 'border-indigo-500 bg-indigo-950/30 scale-[1.01]'
            : 'border-slate-800 bg-slate-900/60 hover:border-slate-700 hover:bg-slate-900'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.docx,.doc,.txt,.md,.csv,image/png,image/jpeg,image/jpg"
          onChange={handleFileInputChange}
          className="hidden"
        />

        <div className="max-w-md mx-auto">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-600/20 to-blue-500/20 border border-indigo-500/30 text-indigo-400 flex items-center justify-center mx-auto mb-4">
            <Upload className="w-8 h-8" />
          </div>

          <h3 className="text-base sm:text-lg font-bold text-white mb-1">
            {t('dragAndDrop')}
          </h3>
          <p className="text-xs text-slate-400 mb-4">{t('supportedFormats')}</p>

          <div className="flex flex-wrap items-center justify-center gap-2 text-[11px] text-slate-400">
            <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 flex items-center gap-1">
              <FileText className="w-3 h-3 text-red-400" /> PDF
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 flex items-center gap-1">
              <FileSpreadsheet className="w-3 h-3 text-blue-400" /> DOCX
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 flex items-center gap-1">
              <FileText className="w-3 h-3 text-emerald-400" /> TXT
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 flex items-center gap-1">
              <ImageIcon className="w-3 h-3 text-purple-400" /> PNG / JPG
            </span>
          </div>

          <div className="mt-5 inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-slate-950/80 border border-slate-800 text-slate-300">
            {activeMode === 'offline' ? (
              <>
                <Lock className="w-3 h-3 text-emerald-400" />
                <span>Offline: 100% on-device text parsing</span>
              </>
            ) : (
              <>
                <Zap className="w-3 h-3 text-blue-400" />
                <span>Online: Gemini 3.8 Flash analysis ready</span>
              </>
            )}
          </div>
        </div>

        {/* Upload & Parsing Progress Overlay */}
        {isProcessing && uploadProgress !== null && (
          <div className="absolute inset-0 bg-slate-950/90 rounded-3xl flex flex-col items-center justify-center p-6 backdrop-blur-sm z-20">
            <div className="w-full max-w-sm text-center">
              <Sparkles className="w-8 h-8 text-indigo-400 animate-spin mx-auto mb-3" />
              <h4 className="text-sm font-bold text-white mb-1">
                Parsing & Extracting Text...
              </h4>
              <p className="text-xs text-slate-400 mb-3 truncate">{currentFileName}</p>
              <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-indigo-500 to-blue-500 h-2.5 rounded-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
              <span className="text-[11px] font-mono text-indigo-300 mt-2 block">
                {uploadProgress}% completed
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Error Notice */}
      {errorMessage && (
        <div className="p-4 rounded-2xl bg-red-950/30 border border-red-500/40 text-red-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Sample Documents Section */}
      <div className="rounded-3xl bg-slate-900/60 border border-slate-800 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-white">{t('sampleDocuments')}</h3>
            <p className="text-xs text-slate-400">
              Instantly explore DocuMind without uploading your own confidential files.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            onClick={onLoadDemoContracts}
            className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-900 transition-all text-left group cursor-pointer"
          >
            <div className="flex items-center justify-between text-xs font-bold text-indigo-400 mb-1">
              <span>Contract v1 & v2 (Conflict Demo)</span>
              <FileText className="w-4 h-4 text-indigo-400" />
            </div>
            <p className="text-[11px] text-slate-400 leading-snug">
              2 revisions with conflicting deadlines (Oct 15 vs 20) and budget changes ($45k vs $58k).
            </p>
          </button>

          <button
            onClick={onLoadDemoAdmissions}
            className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-500/50 hover:bg-slate-900 transition-all text-left group cursor-pointer"
          >
            <div className="flex items-center justify-between text-xs font-bold text-emerald-400 mb-1">
              <span>Graduate Admissions 2026</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-[11px] text-slate-400 leading-snug">
              Detailed directive with 4 deadlines, $32k stipend criteria, and 6-step checklist.
            </p>
          </button>

          <button
            onClick={onLoadDemoPolicy}
            className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-purple-500/50 hover:bg-slate-900 transition-all text-left group cursor-pointer"
          >
            <div className="flex items-center justify-between text-xs font-bold text-purple-400 mb-1">
              <span>Remote Work Policy</span>
              <Sparkles className="w-4 h-4 text-purple-400" />
            </div>
            <p className="text-[11px] text-slate-400 leading-snug">
              Security directive with ambiguous clauses for clarity scoring & recommendations.
            </p>
          </button>
        </div>
      </div>

      {/* Uploaded Documents List */}
      <div className="rounded-3xl bg-slate-900/80 border border-slate-800 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white">Stored Documents ({documents.length})</h3>
        </div>

        {documents.length === 0 ? (
          <div className="text-center py-10 text-slate-500 text-xs">
            No documents uploaded yet. Upload a file above or load a sample document.
          </div>
        ) : (
          <div className="divide-y divide-slate-800/80">
            {documents.map((doc) => (
              <div
                key={doc.id}
                className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 first:pt-0 last:pb-0"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0 mt-0.5">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">{doc.title}</h4>
                    <div className="flex flex-wrap items-center gap-2 mt-1 text-[11px] text-slate-400">
                      <span>{doc.fileName}</span>
                      <span>•</span>
                      <span>{(doc.fileSize / 1024).toFixed(1)} KB</span>
                      <span>•</span>
                      <span>{doc.analysis?.wordCount || 0} words</span>
                      {doc.analysis?.clarityScore && (
                        <>
                          <span>•</span>
                          <span className="text-indigo-400 font-semibold">
                            Clarity: {doc.analysis.clarityScore}/100
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    onClick={() => onAnalyzeDocument(doc.id)}
                    className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-sm shadow-indigo-600/30"
                  >
                    <Search className="w-3.5 h-3.5" />
                    <span>Analyze</span>
                  </button>
                  <button
                    onClick={() => onDeleteDocument(doc.id)}
                    className="p-1.5 rounded-xl bg-slate-800 hover:bg-red-500/20 text-slate-400 hover:text-red-300 transition-colors cursor-pointer"
                    title="Remove document"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
