import React, { useState, useEffect } from 'react';
import {
  AppMode,
  DocumentRecord,
  Language,
  NavView,
  SmartAlert,
  ConflictItem,
  ComparisonResult,
} from './types';
import { StorageService } from './utils/storage';
import { LandingPage } from './components/LandingPage';
import { ModeSelectModal } from './components/ModeSelectModal';
import { TopNav } from './components/TopNav';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { DocumentUploadView } from './components/DocumentUploadView';
import { AnalyzeView } from './components/AnalyzeView';
import { CompareView } from './components/CompareView';
import { ConflictsView } from './components/ConflictsView';
import { ActionItemsView } from './components/ActionItemsView';
import { AlertsView } from './components/AlertsView';
import { VoiceView } from './components/VoiceView';
import { PrivacyView } from './components/PrivacyView';
import {
  DEMO_DOC_A_CONTRACT,
  DEMO_DOC_B_CONTRACT,
  DEMO_DOC_ADMISSIONS,
  DEMO_DOC_POLICY,
  DEMO_COMPARISON_CONTRACTS,
} from './utils/demoData';
import { playChime } from './utils/sound';
import { voiceEngine } from './utils/voice';
import { analyzeDocumentOffline, compareDocumentsOffline } from './utils/fileExtractor';

export default function App() {
  // App Navigation and Engine States
  const [currentView, setCurrentView] = useState<NavView>('landing');
  const [activeMode, setActiveMode] = useState<AppMode>(StorageService.getMode());
  const [privacyMode, setPrivacyMode] = useState<boolean>(StorageService.getPrivacyMode());
  const [language, setLanguage] = useState<Language>(StorageService.getLanguage());
  const [soundMuted, setSoundMuted] = useState<boolean>(StorageService.isSoundMuted());

  // Mode Selection Modal
  const [showModeModal, setShowModeModal] = useState<boolean>(false);

  // Documents & Active Selection
  const [documents, setDocuments] = useState<DocumentRecord[]>(StorageService.getDocuments());
  const [activeDocId, setActiveDocId] = useState<string>(StorageService.getActiveDocId());

  // Comparison State
  const [docAId, setDocAId] = useState<string>(StorageService.getCompareDocAId());
  const [docBId, setDocBId] = useState<string>(StorageService.getCompareDocBId());
  const [comparisonResult, setComparisonResult] = useState<ComparisonResult>(
    StorageService.getComparisonResult()
  );
  const [isComparing, setIsComparing] = useState<boolean>(false);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);

  // Conflict Status Map (conflictId -> 'resolved' | 'ignored' | 'important' | 'unresolved')
  const [conflictStatuses, setConflictStatuses] = useState<
    Record<string, 'resolved' | 'ignored' | 'important' | 'unresolved'>
  >(StorageService.getConflictStatuses());

  // Action Items Completed Map (actId -> boolean)
  const [actionCompletedMap, setActionCompletedMap] = useState<Record<string, boolean>>(
    StorageService.getActionCompletedMap()
  );

  // Smart Alerts
  const [alerts, setAlerts] = useState<SmartAlert[]>(StorageService.getAlerts());

  // Search & Voice
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isVoiceListening, setIsVoiceListening] = useState<boolean>(false);

  // Sync settings to Storage
  useEffect(() => {
    StorageService.setMode(activeMode);
  }, [activeMode]);

  useEffect(() => {
    StorageService.setPrivacyMode(privacyMode);
  }, [privacyMode]);

  useEffect(() => {
    StorageService.setLanguage(language);
  }, [language]);

  useEffect(() => {
    StorageService.setSoundMuted(soundMuted);
  }, [soundMuted]);

  useEffect(() => {
    StorageService.setActiveDocId(activeDocId);
  }, [activeDocId]);

  useEffect(() => {
    StorageService.setCompareDocAId(docAId);
  }, [docAId]);

  useEffect(() => {
    StorageService.setCompareDocBId(docBId);
  }, [docBId]);

  // Voice Engine State listener
  useEffect(() => {
    const unsub = voiceEngine.subscribe((state) => {
      setIsVoiceListening(state.isListening);
    });
    return () => {
      unsub();
    };
  }, []);

  // Handlers
  const handleToggleMode = () => {
    const nextMode = activeMode === 'offline' ? 'online' : 'offline';
    setActiveMode(nextMode);
    playChime('alert', soundMuted);
  };

  const handleTogglePrivacy = () => {
    const nextVal = !privacyMode;
    setPrivacyMode(nextVal);
    playChime('alert', soundMuted);
  };

  const handleToggleSound = () => {
    setSoundMuted(!soundMuted);
  };

  const handleSelectMode = (mode: AppMode) => {
    setActiveMode(mode);
    setShowModeModal(false);
    if (currentView === 'landing' || currentView === 'mode-select') {
      setCurrentView('dashboard');
    }
    playChime('success', soundMuted);
  };

  const handleAddDocument = (doc: DocumentRecord) => {
    StorageService.addDocument(doc);
    const updated = StorageService.getDocuments();
    setDocuments(updated);
    setActiveDocId(doc.id);
    playChime('success', soundMuted);

    // Add alert for new document analyzed
    const newAlert: SmartAlert = {
      id: `alt-${Date.now()}`,
      title: 'Document Analysis Ready',
      message: `"${doc.title}" processed successfully (${doc.analysis?.wordCount || 0} words).`,
      category: 'info',
      timestamp: 'Just now',
      read: false,
      actionView: 'analyze',
    };
    const updatedAlerts = [newAlert, ...alerts];
    setAlerts(updatedAlerts);
    StorageService.saveAlerts(updatedAlerts);
  };

  const handleDeleteDocument = (id: string) => {
    StorageService.deleteDocument(id);
    const updated = StorageService.getDocuments();
    setDocuments(updated);
    if (activeDocId === id && updated.length > 0) {
      setActiveDocId(updated[0].id);
    }
    playChime('alert', soundMuted);
  };

  const handleSelectDoc = (id: string) => {
    setActiveDocId(id);
  };

  const handleAnalyzeDocument = (id: string) => {
    setActiveDocId(id);
    setCurrentView('analyze');
  };

  // Re-analyze document using server Gemini endpoint (with local heuristic fallback)
  const handleReanalyzeWithGemini = async (docId: string) => {
    const targetDoc = documents.find((d) => d.id === docId);
    if (!targetDoc) return;

    setIsAnalyzing(true);
    playChime('alert', soundMuted);

    try {
      if (activeMode === 'online') {
        const res = await fetch('/api/analyze', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text: targetDoc.content,
            title: targetDoc.title,
            language,
            mode: 'online',
          }),
        });

        if (res.ok) {
          const resData = await res.json();
          if (resData.success && resData.data) {
            const updatedDoc: DocumentRecord = {
              ...targetDoc,
              analysis: {
                ...resData.data,
                source: resData.source || 'gemini-3.8-flash',
              },
            };
            StorageService.addDocument(updatedDoc);
            setDocuments(StorageService.getDocuments());
            setIsAnalyzing(false);
            playChime('success', soundMuted);
            return;
          }
        }
      }
    } catch (e) {
      console.warn('Server online analysis failed, using local engine:', e);
    }

    // Fallback on-device analysis
    const localRes = analyzeDocumentOffline(targetDoc.content, targetDoc.title);
    const updatedDoc: DocumentRecord = {
      ...targetDoc,
      analysis: localRes,
    };
    StorageService.addDocument(updatedDoc);
    setDocuments(StorageService.getDocuments());
    setIsAnalyzing(false);
    playChime('success', soundMuted);
  };

  // Run Comparison between Doc A and Doc B
  const handleRunComparison = async () => {
    const docA = documents.find((d) => d.id === docAId);
    const docB = documents.find((d) => d.id === docBId);
    if (!docA || !docB) return;

    setIsComparing(true);
    playChime('alert', soundMuted);

    try {
      if (activeMode === 'online') {
        const res = await fetch('/api/compare', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            docA: { title: docA.title, text: docA.content },
            docB: { title: docB.title, text: docB.content },
            language,
            mode: 'online',
          }),
        });

        if (res.ok) {
          const resData = await res.json();
          if (resData.success && resData.data) {
            setComparisonResult(resData.data);
            StorageService.setComparisonResult(resData.data);
            setIsComparing(false);
            playChime('conflict', soundMuted);
            return;
          }
        }
      }
    } catch (e) {
      console.warn('Online comparison call failed, using local comparator:', e);
    }

    // Local Comparison Fallback
    const localDiff = compareDocumentsOffline(
      { title: docA.title, text: docA.content },
      { title: docB.title, text: docB.content }
    );
    setComparisonResult(localDiff);
    StorageService.setComparisonResult(localDiff);
    setIsComparing(false);
    playChime('conflict', soundMuted);
  };

  // Conflict Resolution Update
  const handleUpdateConflictStatus = (
    id: string,
    status: 'resolved' | 'ignored' | 'important' | 'unresolved'
  ) => {
    StorageService.setConflictStatus(id, status);
    setConflictStatuses({ ...StorageService.getConflictStatuses() });
    playChime(status === 'resolved' ? 'success' : 'alert', soundMuted);
  };

  // Toggle Action item completed
  const handleToggleActionItem = (id: string) => {
    StorageService.toggleActionCompleted(id);
    setActionCompletedMap({ ...StorageService.getActionCompletedMap() });
    playChime('alert', soundMuted);
  };

  // Mark Alert Read
  const handleMarkAlertRead = (id: string) => {
    StorageService.markAlertRead(id);
    setAlerts(StorageService.getAlerts());
  };

  // Clear all local data
  const handleClearAllData = () => {
    StorageService.clearAllData();
    setDocuments(StorageService.getDocuments());
    setConflictStatuses({});
    setActionCompletedMap({});
    setAlerts([]);
    playChime('alert', soundMuted);
  };

  // Sample Loaders
  const handleLoadDemoContracts = () => {
    StorageService.addDocument(DEMO_DOC_A_CONTRACT);
    StorageService.addDocument(DEMO_DOC_B_CONTRACT);
    setDocuments(StorageService.getDocuments());
    setDocAId(DEMO_DOC_A_CONTRACT.id);
    setDocBId(DEMO_DOC_B_CONTRACT.id);
    setComparisonResult(DEMO_COMPARISON_CONTRACTS);
    StorageService.setComparisonResult(DEMO_COMPARISON_CONTRACTS);
    setCurrentView('compare');
    playChime('success', soundMuted);
  };

  const handleLoadDemoAdmissions = () => {
    StorageService.addDocument(DEMO_DOC_ADMISSIONS);
    setDocuments(StorageService.getDocuments());
    setActiveDocId(DEMO_DOC_ADMISSIONS.id);
    setCurrentView('analyze');
    playChime('success', soundMuted);
  };

  const handleLoadDemoPolicy = () => {
    StorageService.addDocument(DEMO_DOC_POLICY);
    setDocuments(StorageService.getDocuments());
    setActiveDocId(DEMO_DOC_POLICY.id);
    setCurrentView('analyze');
    playChime('success', soundMuted);
  };

  // Voice Command Dispatcher
  const handleVoiceCommand = (command: string) => {
    const lower = command.toLowerCase();
    if (lower.includes('deadline') || lower.includes('action') || lower.includes('task')) {
      setCurrentView('actions');
    } else if (lower.includes('summary') || lower.includes('read')) {
      const activeDoc = documents.find((d) => d.id === activeDocId);
      if (activeDoc?.analysis?.summary) {
        voiceEngine.speak(activeDoc.analysis.summary, language);
      }
    } else if (lower.includes('conflict') || lower.includes('contradiction')) {
      setCurrentView('conflicts');
    } else if (lower.includes('compare') || lower.includes('diff')) {
      setCurrentView('compare');
    } else if (lower.includes('offline')) {
      setActiveMode('offline');
      voiceEngine.speak('Switched to offline mode.', language);
    } else if (lower.includes('online')) {
      setActiveMode('online');
      voiceEngine.speak('Switched to online mode.', language);
    } else if (lower.includes('privacy')) {
      setPrivacyMode(true);
      voiceEngine.speak('Privacy mode enabled.', language);
    } else if (lower.includes('document') || lower.includes('upload')) {
      setCurrentView('documents');
    } else {
      setCurrentView('dashboard');
    }
  };

  // Active document resolution
  const activeDocument = documents.find((d) => d.id === activeDocId) || documents[0] || null;

  // Filtered documents for search
  const filteredDocuments = documents.filter((doc) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      doc.title.toLowerCase().includes(q) ||
      doc.fileName.toLowerCase().includes(q) ||
      doc.content.toLowerCase().includes(q)
    );
  });

  // Landing Page View
  if (currentView === 'landing') {
    return (
      <LandingPage
        onGetStarted={() => setShowModeModal(true)}
        onTryOffline={() => {
          setActiveMode('offline');
          setCurrentView('dashboard');
        }}
        currentLanguage={language}
        onLanguageChange={setLanguage}
      />
    );
  }

  // Active conflict items calculation
  const allConflicts = comparisonResult.conflicts || [];
  const unresolvedConflictsCount = allConflicts.filter(
    (c) => (conflictStatuses[c.id] || c.status) === 'unresolved'
  ).length;

  // Deadlines count
  const allDeadlines = documents.flatMap((d) => d.analysis?.deadlines || []);
  const unreadAlertsCount = alerts.filter((a) => !a.read).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Mode Selection Modal */}
      {showModeModal && (
        <ModeSelectModal
          currentMode={activeMode}
          currentLanguage={language}
          onSelectMode={handleSelectMode}
          onClose={() => setShowModeModal(false)}
          isModal={true}
        />
      )}

      {/* Main Layout: Sidebar + TopNav + Content View */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          currentView={currentView}
          onNavigate={setCurrentView}
          activeMode={activeMode}
          language={language}
          conflictCount={unresolvedConflictsCount}
          deadlineCount={allDeadlines.length}
          alertCount={unreadAlertsCount}
          onOpenModeSelect={() => setShowModeModal(true)}
        />

        {/* Right Application Stage */}
        <div className="flex-1 flex flex-col h-screen overflow-y-auto">
          {/* Top Navigation Bar */}
          <TopNav
            currentMode={activeMode}
            onToggleMode={handleToggleMode}
            privacyMode={privacyMode}
            onTogglePrivacy={handleTogglePrivacy}
            language={language}
            onLanguageChange={setLanguage}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            alerts={alerts}
            onOpenAlerts={() => setCurrentView('alerts')}
            soundMuted={soundMuted}
            onToggleSound={handleToggleSound}
            isListening={isVoiceListening}
            onToggleVoiceCommand={() => {
              if (isVoiceListening) {
                voiceEngine.stopListening();
              } else {
                voiceEngine.startListening(language, handleVoiceCommand);
              }
            }}
          />

          {/* Main View Area */}
          <main className="flex-1 p-6 sm:p-8 max-w-7xl w-full mx-auto pb-16">
            {currentView === 'dashboard' && (
              <DashboardView
                documents={filteredDocuments}
                activeMode={activeMode}
                privacyMode={privacyMode}
                language={language}
                onNavigate={setCurrentView}
                onSelectDoc={handleSelectDoc}
                onLoadDemoContracts={handleLoadDemoContracts}
                conflicts={allConflicts}
                onResolveConflict={(id) => handleUpdateConflictStatus(id, 'resolved')}
                onToggleActionItem={handleToggleActionItem}
                actionCompletedMap={actionCompletedMap}
              />
            )}

            {currentView === 'documents' && (
              <DocumentUploadView
                documents={filteredDocuments}
                activeMode={activeMode}
                language={language}
                onAddDocument={handleAddDocument}
                onDeleteDocument={handleDeleteDocument}
                onAnalyzeDocument={handleAnalyzeDocument}
                onLoadDemoContracts={handleLoadDemoContracts}
                onLoadDemoAdmissions={handleLoadDemoAdmissions}
                onLoadDemoPolicy={handleLoadDemoPolicy}
              />
            )}

            {currentView === 'analyze' && (
              <AnalyzeView
                document={activeDocument}
                documents={documents}
                onSelectDoc={handleSelectDoc}
                activeMode={activeMode}
                language={language}
                onReanalyzeWithGemini={handleReanalyzeWithGemini}
                isAnalyzing={isAnalyzing}
                onToggleActionItem={handleToggleActionItem}
                actionCompletedMap={actionCompletedMap}
              />
            )}

            {currentView === 'compare' && (
              <CompareView
                documents={documents}
                docAId={docAId}
                docBId={docBId}
                onSelectDocA={setDocAId}
                onSelectDocB={setDocBId}
                comparisonResult={comparisonResult}
                onRunComparison={handleRunComparison}
                isComparing={isComparing}
                activeMode={activeMode}
                language={language}
                onNavigateToConflicts={() => setCurrentView('conflicts')}
              />
            )}

            {currentView === 'conflicts' && (
              <ConflictsView
                conflicts={allConflicts}
                conflictStatuses={conflictStatuses}
                onUpdateStatus={handleUpdateConflictStatus}
                language={language}
              />
            )}

            {currentView === 'actions' && (
              <ActionItemsView
                documents={documents}
                onToggleActionItem={handleToggleActionItem}
                actionCompletedMap={actionCompletedMap}
                language={language}
              />
            )}

            {currentView === 'alerts' && (
              <AlertsView
                alerts={alerts}
                onMarkRead={handleMarkAlertRead}
                onNavigate={setCurrentView}
                soundMuted={soundMuted}
                onToggleSound={handleToggleSound}
                language={language}
              />
            )}

            {currentView === 'voice' && (
              <VoiceView
                activeDoc={activeDocument}
                conflicts={allConflicts}
                language={language}
                onVoiceNavigate={setCurrentView}
                onVoiceCommandRecognized={handleVoiceCommand}
              />
            )}

            {currentView === 'privacy' && (
              <PrivacyView
                privacyMode={privacyMode}
                onTogglePrivacy={handleTogglePrivacy}
                activeMode={activeMode}
                onClearAllData={handleClearAllData}
                language={language}
              />
            )}
          </main>
        </div>
      </div>
    </div>
  );
}
